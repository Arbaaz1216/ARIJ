#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <fstream>
#include <iostream>
#include <string>
#include <QFile>
#include <QTextStream>

QString userPt;

using namespace std;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //myDB = QSqlDatabase::addDatabase("QSQLITE");
    //myDB.setDatabaseName("C:/sqlite2/LMS.db");

    if(!connOpen())
    {
        ui->label_15->setText("Failed");
    }
    else
    {
        ui->label_15->setText("online");
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_Admin_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(1);
}

void MainWindow::on_pushButton_Student_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(2);
}

void MainWindow::on_pushButton_Return_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_Return_2_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_AdminLogin_clicked()
{
        QString username_admin, password_admin;
        username_admin = ui->lineEdit_AdminLogin->text();
        password_admin = ui->lineEdit_AdminPass->text();

        if(!connOpen())
        {
            qDebug() << "Database failed to open.";
            return;
        }

        connOpen();

        QSqlQuery qry;
        qry.prepare("select * from ad where name = '"+username_admin+"' and pass = '"+password_admin+"' ");

   if (qry.exec())
        {
            int count = 0;

            while(qry.next())
            {
                count++;
            }

            if(count ==1)
            {
                connClose();
                QMessageBox::information(this, "Login File", "You have logged in as admin.");
                   ui->stackedWidget_Main->setCurrentIndex(3);
            }
           else if(count >1)
            {
                qDebug() << "Duplicate";
            }
          else  if(count < 1)
            {
                QMessageBox::warning(this, "Login", "Incorrect username and password.");
            }
        }


        ui->lineEdit_AdminLogin->clear();
        ui->lineEdit_AdminPass->clear();
}

void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_StudLogin_clicked()
{
    QString username_stu, password_stu;
    username_stu = ui->lineEdit_StudLogin->text();
    password_stu = ui->lineEdit_StudPass->text();

    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
    qry.prepare("select * from student where name = '"+username_stu+"' and pass = '"+password_stu+"' ");

if (qry.exec())
    {
        int count = 0;

        while(qry.next())
        {
            count++;
        }

        if(count ==1)
        {
            QMessageBox::information(this, "Login File", "You have logged in.");
            connClose();
               ui->stackedWidget_Main->setCurrentIndex(4);
               QFile fileWelcome("data\\StudentWelcome.txt");
                if(!fileWelcome.open(QIODevice::ReadOnly))
                    QMessageBox::information(0, "info", fileWelcome.errorString());

                QTextStream in(&fileWelcome);
               ui->textBrowser->setText(in.readAll());
               ui->label_13->setText(username_stu);
              // QString IDString = QString::number(id);
              // ui->label_ID->setText(IDString);
        }
       else if(count >1)
        {
            qDebug() << "Duplicate";
        }
      else  if(count < 1)
        {
            QMessageBox::warning(this, "Login", "Incorrect username and password.");
        }
    }

userPt = username_stu;
    ui->lineEdit_StudLogin->clear();
    ui->lineEdit_StudPass->clear();
}

void MainWindow::on_pushButton_6_clicked()
{
      /*  ui->stackedWidget_2->setCurrentIndex(1);
       QFile fileCourses("data\\students\\courses\\" + userPt + ".txt");
      if(!fileCourses.open(QIODevice::ReadOnly))
           QMessageBox::information(0, "info", fileCourses.errorString());

       QTextStream in(&fileCourses);
      ui->textBrowser_Courses->setText(in.readAll());*/

   // MainWindow conn;
    ui->stackedWidget_2->setCurrentIndex(1);
    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    qry->prepare("select studid from student where name = '"+userPt+"'");
    qry->exec();

    model->setQuery(*qry);
    ui->tableView->setModel(model);
    connClose();
    qDebug() << (model->rowCount());
}

void MainWindow::on_pushButton_StudLogout_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
        ClearAll();
}

void MainWindow::on_pushButton_8_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(0);
}

void MainWindow::on_pushButton_7_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(2);
   QFile fileGrades("data\\students\\grades\\" + userPt + ".txt");
   if(!fileGrades.open(QIODevice::ReadOnly))
       QMessageBox::information(0, "info", fileGrades.errorString());

   QTextStream in(&fileGrades);
  ui->textBrowser_Grades->setText(in.readAll());
}

void MainWindow::on_pushButton_GPA_clicked()
{
    double GPA = 0.0;
    QString GPAString = QString::number(GPA);
    ui->label_GPA->setText(GPAString);
}

void MainWindow::ClearAll()
{
    ui->label_GPA->clear();
}

void MainWindow::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    QSqlQueryModel * model2 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    qry->prepare("select * from student");
    qry->exec();

    model2->setQuery(*qry);
    ui->tableView_2->setModel(model2);
    connClose();
    qDebug() << (model2->rowCount());
}
