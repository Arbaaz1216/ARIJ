/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout;
    QStackedWidget *stackedWidget_Main;
    QWidget *page_Main;
    QPushButton *pushButton_Student;
    QLabel *label;
    QPushButton *pushButton_Admin;
    QLabel *label_Title;
    QLabel *label_8;
    QWidget *page_AdminLogi;
    QLabel *label_AdminLogin;
    QPushButton *pushButton_Return;
    QLineEdit *lineEdit_AdminLogin;
    QLineEdit *lineEdit_AdminPass;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *pushButton_AdminLogin;
    QLabel *label_6;
    QLabel *label_15;
    QWidget *page_StudentLogin;
    QLabel *label_StudLogin;
    QPushButton *pushButton_Return_2;
    QLineEdit *lineEdit_StudLogin;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *lineEdit_StudPass;
    QPushButton *pushButton_StudLogin;
    QLabel *label_7;
    QWidget *page_adminPanel;
    QLabel *label_AdminPanel;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QLabel *label_AdminMain;
    QWidget *page_ViewStud;
    QTableView *tableView_2;
    QWidget *page_StudentPanel;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_StudLogout;
    QStackedWidget *stackedWidget_2;
    QWidget *page_StudMain;
    QLabel *label_9;
    QTextBrowser *textBrowser;
    QLabel *label_10;
    QWidget *page_4;
    QTableView *tableView;
    QWidget *page_StudViewGrades;
    QTextBrowser *textBrowser_Grades;
    QPushButton *pushButton_GPA;
    QLabel *label_GPA;
    QPushButton *pushButton_8;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_ID;
    QLabel *label_14;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        MainWindow->setMinimumSize(QSize(800, 600));
        MainWindow->setMaximumSize(QSize(800, 600));
        MainWindow->setWindowOpacity(1.000000000000000);
        MainWindow->setAutoFillBackground(false);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout = new QHBoxLayout(centralWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        stackedWidget_Main = new QStackedWidget(centralWidget);
        stackedWidget_Main->setObjectName(QString::fromUtf8("stackedWidget_Main"));
        page_Main = new QWidget();
        page_Main->setObjectName(QString::fromUtf8("page_Main"));
        pushButton_Student = new QPushButton(page_Main);
        pushButton_Student->setObjectName(QString::fromUtf8("pushButton_Student"));
        pushButton_Student->setGeometry(QRect(320, 170, 171, 23));
        label = new QLabel(page_Main);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(310, 250, 200, 191));
        label->setPixmap(QPixmap(QString::fromUtf8(":/images/images/gator.png")));
        pushButton_Admin = new QPushButton(page_Main);
        pushButton_Admin->setObjectName(QString::fromUtf8("pushButton_Admin"));
        pushButton_Admin->setGeometry(QRect(320, 140, 171, 23));
        label_Title = new QLabel(page_Main);
        label_Title->setObjectName(QString::fromUtf8("label_Title"));
        label_Title->setGeometry(QRect(120, 20, 592, 111));
        label_8 = new QLabel(page_Main);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(340, 450, 129, 13));
        stackedWidget_Main->addWidget(page_Main);
        page_AdminLogi = new QWidget();
        page_AdminLogi->setObjectName(QString::fromUtf8("page_AdminLogi"));
        label_AdminLogin = new QLabel(page_AdminLogi);
        label_AdminLogin->setObjectName(QString::fromUtf8("label_AdminLogin"));
        label_AdminLogin->setGeometry(QRect(330, 100, 128, 16));
        pushButton_Return = new QPushButton(page_AdminLogi);
        pushButton_Return->setObjectName(QString::fromUtf8("pushButton_Return"));
        pushButton_Return->setGeometry(QRect(10, 500, 75, 23));
        lineEdit_AdminLogin = new QLineEdit(page_AdminLogi);
        lineEdit_AdminLogin->setObjectName(QString::fromUtf8("lineEdit_AdminLogin"));
        lineEdit_AdminLogin->setGeometry(QRect(300, 140, 181, 21));
        lineEdit_AdminPass = new QLineEdit(page_AdminLogi);
        lineEdit_AdminPass->setObjectName(QString::fromUtf8("lineEdit_AdminPass"));
        lineEdit_AdminPass->setGeometry(QRect(300, 190, 181, 21));
        lineEdit_AdminPass->setEchoMode(QLineEdit::Password);
        label_2 = new QLabel(page_AdminLogi);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(300, 120, 47, 13));
        label_3 = new QLabel(page_AdminLogi);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(300, 170, 47, 13));
        pushButton_AdminLogin = new QPushButton(page_AdminLogi);
        pushButton_AdminLogin->setObjectName(QString::fromUtf8("pushButton_AdminLogin"));
        pushButton_AdminLogin->setGeometry(QRect(350, 220, 75, 23));
        label_6 = new QLabel(page_AdminLogi);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(350, 260, 86, 13));
        label_15 = new QLabel(page_AdminLogi);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(380, 390, 211, 16));
        stackedWidget_Main->addWidget(page_AdminLogi);
        page_StudentLogin = new QWidget();
        page_StudentLogin->setObjectName(QString::fromUtf8("page_StudentLogin"));
        label_StudLogin = new QLabel(page_StudentLogin);
        label_StudLogin->setObjectName(QString::fromUtf8("label_StudLogin"));
        label_StudLogin->setGeometry(QRect(340, 100, 91, 20));
        pushButton_Return_2 = new QPushButton(page_StudentLogin);
        pushButton_Return_2->setObjectName(QString::fromUtf8("pushButton_Return_2"));
        pushButton_Return_2->setGeometry(QRect(10, 500, 75, 23));
        lineEdit_StudLogin = new QLineEdit(page_StudentLogin);
        lineEdit_StudLogin->setObjectName(QString::fromUtf8("lineEdit_StudLogin"));
        lineEdit_StudLogin->setGeometry(QRect(300, 140, 181, 21));
        label_4 = new QLabel(page_StudentLogin);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(300, 170, 47, 13));
        label_5 = new QLabel(page_StudentLogin);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(300, 120, 47, 13));
        lineEdit_StudPass = new QLineEdit(page_StudentLogin);
        lineEdit_StudPass->setObjectName(QString::fromUtf8("lineEdit_StudPass"));
        lineEdit_StudPass->setGeometry(QRect(300, 190, 181, 21));
        lineEdit_StudPass->setEchoMode(QLineEdit::Password);
        pushButton_StudLogin = new QPushButton(page_StudentLogin);
        pushButton_StudLogin->setObjectName(QString::fromUtf8("pushButton_StudLogin"));
        pushButton_StudLogin->setGeometry(QRect(350, 220, 75, 23));
        label_7 = new QLabel(page_StudentLogin);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(350, 260, 86, 13));
        stackedWidget_Main->addWidget(page_StudentLogin);
        page_adminPanel = new QWidget();
        page_adminPanel->setObjectName(QString::fromUtf8("page_adminPanel"));
        label_AdminPanel = new QLabel(page_adminPanel);
        label_AdminPanel->setObjectName(QString::fromUtf8("label_AdminPanel"));
        label_AdminPanel->setGeometry(QRect(320, 10, 130, 25));
        pushButton = new QPushButton(page_adminPanel);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(10, 500, 75, 23));
        pushButton_2 = new QPushButton(page_adminPanel);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(20, 50, 121, 23));
        pushButton_3 = new QPushButton(page_adminPanel);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(20, 80, 121, 23));
        pushButton_4 = new QPushButton(page_adminPanel);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(20, 110, 121, 23));
        pushButton_5 = new QPushButton(page_adminPanel);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(20, 140, 121, 23));
        stackedWidget = new QStackedWidget(page_adminPanel);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(150, 40, 621, 491));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        label_AdminMain = new QLabel(page);
        label_AdminMain->setObjectName(QString::fromUtf8("label_AdminMain"));
        label_AdminMain->setGeometry(QRect(40, 40, 481, 61));
        stackedWidget->addWidget(page);
        page_ViewStud = new QWidget();
        page_ViewStud->setObjectName(QString::fromUtf8("page_ViewStud"));
        tableView_2 = new QTableView(page_ViewStud);
        tableView_2->setObjectName(QString::fromUtf8("tableView_2"));
        tableView_2->setGeometry(QRect(0, 0, 611, 471));
        stackedWidget->addWidget(page_ViewStud);
        stackedWidget_Main->addWidget(page_adminPanel);
        page_StudentPanel = new QWidget();
        page_StudentPanel->setObjectName(QString::fromUtf8("page_StudentPanel"));
        pushButton_6 = new QPushButton(page_StudentPanel);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(20, 30, 111, 23));
        pushButton_7 = new QPushButton(page_StudentPanel);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(140, 30, 111, 23));
        pushButton_StudLogout = new QPushButton(page_StudentPanel);
        pushButton_StudLogout->setObjectName(QString::fromUtf8("pushButton_StudLogout"));
        pushButton_StudLogout->setGeometry(QRect(690, 20, 75, 23));
        stackedWidget_2 = new QStackedWidget(page_StudentPanel);
        stackedWidget_2->setObjectName(QString::fromUtf8("stackedWidget_2"));
        stackedWidget_2->setGeometry(QRect(20, 60, 751, 461));
        page_StudMain = new QWidget();
        page_StudMain->setObjectName(QString::fromUtf8("page_StudMain"));
        label_9 = new QLabel(page_StudMain);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(0, 110, 131, 16));
        textBrowser = new QTextBrowser(page_StudMain);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(0, 140, 751, 331));
        label_10 = new QLabel(page_StudMain);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(0, 0, 521, 81));
        stackedWidget_2->addWidget(page_StudMain);
        page_4 = new QWidget();
        page_4->setObjectName(QString::fromUtf8("page_4"));
        tableView = new QTableView(page_4);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(0, 10, 431, 441));
        stackedWidget_2->addWidget(page_4);
        page_StudViewGrades = new QWidget();
        page_StudViewGrades->setObjectName(QString::fromUtf8("page_StudViewGrades"));
        textBrowser_Grades = new QTextBrowser(page_StudViewGrades);
        textBrowser_Grades->setObjectName(QString::fromUtf8("textBrowser_Grades"));
        textBrowser_Grades->setGeometry(QRect(0, 20, 371, 431));
        pushButton_GPA = new QPushButton(page_StudViewGrades);
        pushButton_GPA->setObjectName(QString::fromUtf8("pushButton_GPA"));
        pushButton_GPA->setGeometry(QRect(10, 420, 81, 23));
        label_GPA = new QLabel(page_StudViewGrades);
        label_GPA->setObjectName(QString::fromUtf8("label_GPA"));
        label_GPA->setGeometry(QRect(100, 420, 91, 21));
        stackedWidget_2->addWidget(page_StudViewGrades);
        pushButton_8 = new QPushButton(page_StudentPanel);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(610, 20, 75, 23));
        label_11 = new QLabel(page_StudentPanel);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(320, 0, 141, 21));
        label_12 = new QLabel(page_StudentPanel);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(20, 10, 71, 16));
        label_13 = new QLabel(page_StudentPanel);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(90, 10, 81, 16));
        label_ID = new QLabel(page_StudentPanel);
        label_ID->setObjectName(QString::fromUtf8("label_ID"));
        label_ID->setGeometry(QRect(220, 10, 71, 16));
        label_14 = new QLabel(page_StudentPanel);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(160, 10, 81, 16));
        stackedWidget_Main->addWidget(page_StudentPanel);

        horizontalLayout->addWidget(stackedWidget_Main);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 800, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "ARIJ", nullptr));
        pushButton_Student->setText(QApplication::translate("MainWindow", "Student", nullptr));
        label->setText(QString());
        pushButton_Admin->setText(QApplication::translate("MainWindow", "Administrator", nullptr));
        label_Title->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:24pt; font-weight:600; color:#00aaff;\">ARIJ - Learning Management System</span></p><p align=\"center\"><br/></p><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#a5a5a5;\">Please select from the following menu.</span></p></body></html>", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d4d4d4;\">Copyright 2019 ARIJ - LMS</span></p></body></html>", nullptr));
        label_AdminLogin->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Administrator Login</span></p></body></html>", nullptr));
        pushButton_Return->setText(QApplication::translate("MainWindow", "Return", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Username", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "Password", nullptr));
        pushButton_AdminLogin->setText(QApplication::translate("MainWindow", "Login", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#0000ff;\">Forgot password?</span></p></body></html>", nullptr));
        label_15->setText(QApplication::translate("MainWindow", "[+]Status", nullptr));
        label_StudLogin->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Student Login</span></p></body></html>", nullptr));
        pushButton_Return_2->setText(QApplication::translate("MainWindow", "Return", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "Password", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "Username", nullptr));
        pushButton_StudLogin->setText(QApplication::translate("MainWindow", "Login", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#0000ff;\">Forgot password?</span></p></body></html>", nullptr));
        label_AdminPanel->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; font-weight:600;\">Admin Panel</span></p></body></html>", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "Logout", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "View Students", nullptr));
        pushButton_3->setText(QApplication::translate("MainWindow", "Manage Students", nullptr));
        pushButton_4->setText(QApplication::translate("MainWindow", "View Course", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "Manage Courses", nullptr));
        label_AdminMain->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Welcome to the admin panel. </p><p>Here you can manage your courses &amp; manage any students registered.</p><p>Use the buttons to navigate the panel.</p></body></html>", nullptr));
        pushButton_6->setText(QApplication::translate("MainWindow", "View My Courses", nullptr));
        pushButton_7->setText(QApplication::translate("MainWindow", "View Grades", nullptr));
        pushButton_StudLogout->setText(QApplication::translate("MainWindow", "Logout", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:11pt; font-weight:600;\">Announcements</span></p></body></html>", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Welcome to the student panel. Use the buttons to navigate the panel.</p><p>Here you can view your courses, GPA, manage courses, and view the administrator announcements</p></body></html>", nullptr));
        pushButton_GPA->setText(QApplication::translate("MainWindow", "Calculate GPA", nullptr));
        label_GPA->setText(QString());
        pushButton_8->setText(QApplication::translate("MainWindow", "Main Menu", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">Student Panel</span></p></body></html>", nullptr));
        label_12->setText(QApplication::translate("MainWindow", "Logged in as: ", nullptr));
        label_13->setText(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", nullptr));
        label_ID->setText(QString());
        label_14->setText(QApplication::translate("MainWindow", "Student ID:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
