#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_Admin_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(1);
}

void MainWindow::on_pushButton_Student_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(2);
}

void MainWindow::on_pushButton_Return_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_Return_2_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}
