#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_Admin_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(1);
}

void MainWindow::on_pushButton_Student_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(2);
}

void MainWindow::on_pushButton_Return_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_Return_2_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_AdminLogin_clicked()
{
    QString username = ui->lineEdit_AdminLogin->text();
    QString password = ui->lineEdit_AdminPass->text();

    if(username == "admin" && password == "123")
    {
        QMessageBox::information(this, "Login", "You have logged in.");
        ui->stackedWidget_Main->setCurrentIndex(3);
    }
    else {
       QMessageBox::warning(this, "Login", "Incorrect username and password.");
    }
ui->lineEdit_AdminLogin->clear();
ui->lineEdit_AdminPass->clear();
}

void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}
