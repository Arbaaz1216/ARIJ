#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <fstream>
#include <iostream>
#include <string>
#include <QFile>
#include <QTextStream>

QString userPt;

using namespace std;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //myDB = QSqlDatabase::addDatabase("QSQLITE");
    //myDB.setDatabaseName("C:/sqlite2/LMS.db");

    if(!connOpen())
    {
        ui->label_15->setText("Failed");
    }
    else
    {
        ui->label_15->setText("online");
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_Admin_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(1);
}

void MainWindow::on_pushButton_Student_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(2);
}

void MainWindow::on_pushButton_Return_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_Return_2_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_AdminLogin_clicked()
{
        QString username_admin, password_admin;
        username_admin = ui->lineEdit_AdminLogin->text();
        password_admin = ui->lineEdit_AdminPass->text();

        if(!connOpen())
        {
            qDebug() << "Database failed to open.";
            return;
        }

        connOpen();

        QSqlQuery qry;
        qry.prepare("select * from admin where user = '"+username_admin+"' and pass = '"+password_admin+"' ");

   if (qry.exec())
        {
            int count = 0;

            while(qry.next())
            {
                count++;
            }

            if(count ==1)
            {
                connClose();
                QMessageBox::information(this, "Login File", "You have logged in as admin.");
                   ui->stackedWidget_Main->setCurrentIndex(3);
            }
           else if(count >1)
            {
                qDebug() << "Duplicate";
            }
          else  if(count < 1)
            {
                QMessageBox::warning(this, "Login", "Incorrect username and password.");
            }
        }


        ui->lineEdit_AdminLogin->clear();
        ui->lineEdit_AdminPass->clear();
}

void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_StudLogin_clicked()
{
    QString username_stu, password_stu;
    username_stu = ui->lineEdit_StudLogin->text();
    password_stu = ui->lineEdit_StudPass->text();

    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
    qry.prepare("select * from students where user = '"+username_stu+"' and pass = '"+password_stu+"' ");

if (qry.exec())
    {
        int count = 0;

        while(qry.next())
        {
            count++;
        }

        if(count ==1)
        {
            QMessageBox::information(this, "Login File", "You have logged in.");
            connClose();
               ui->stackedWidget_Main->setCurrentIndex(4);
               QFile fileWelcome("data\\StudentWelcome.txt");
                if(!fileWelcome.open(QIODevice::ReadOnly))
                    QMessageBox::information(0, "info", fileWelcome.errorString());

                QTextStream in(&fileWelcome);
               ui->textBrowser->setText(in.readAll());
               ui->label_13->setText(username_stu);
              // QString IDString = QString::number(id);
              // ui->label_ID->setText(IDString);
        }
       else if(count >1)
        {
            qDebug() << "Duplicate";
        }
      else  if(count < 1)
        {
            QMessageBox::warning(this, "Login", "Incorrect username and password.");
        }
    }

userPt = username_stu;
    ui->lineEdit_StudLogin->clear();
    ui->lineEdit_StudPass->clear();
}

void MainWindow::on_pushButton_6_clicked()
{
      /*  ui->stackedWidget_2->setCurrentIndex(1);
       QFile fileCourses("data\\students\\courses\\" + userPt + ".txt");
      if(!fileCourses.open(QIODevice::ReadOnly))
           QMessageBox::information(0, "info", fileCourses.errorString());

       QTextStream in(&fileCourses);
      ui->textBrowser_Courses->setText(in.readAll());*/

   // MainWindow conn;
    ui->stackedWidget_2->setCurrentIndex(1);
    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    qry->prepare("select course1, course2, course3, course4 from courses where user = '"+userPt+"'");
    qry->exec();

    model->setQuery(*qry);
    ui->tableView->setModel(model);
    connClose();
    qDebug() << (model->rowCount());
}

void MainWindow::on_pushButton_StudLogout_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
        ClearAll();
}

void MainWindow::on_pushButton_8_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(0);
}

void MainWindow::on_pushButton_7_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(2);
   QFile fileGrades("data\\students\\grades\\" + userPt + ".txt");
   if(!fileGrades.open(QIODevice::ReadOnly))
       QMessageBox::information(0, "info", fileGrades.errorString());

   QTextStream in(&fileGrades);
  ui->textBrowser_Grades->setText(in.readAll());
}

void MainWindow::on_pushButton_GPA_clicked()
{
    double GPA = 0.0;
    QString GPAString = QString::number(GPA);
    ui->label_GPA->setText(GPAString);
}

void MainWindow::ClearAll()
{
    ui->label_GPA->clear();
}

void MainWindow::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    QSqlQueryModel * model2 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    qry->prepare("select * from students");
    qry->exec();

    model2->setQuery(*qry);
    ui->tableView_2->setModel(model2);
    connClose();
    qDebug() << (model2->rowCount());
}

void MainWindow::on_pushButton_Manage_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}

void MainWindow::on_pushButton_Save_clicked()
{
    QString user, pass, uid, status;
    user = ui->lineEdit_User->text();
    pass = ui->lineEdit_Pass->text();
    uid = ui->lineEdit_UserID->text();
    status = ui->lineEdit_Status->text();

    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
    qry.prepare("insert into students (user, pass, userid, status) values('"+user+"','"+pass+"','"+uid+"','"+status+"')");

if (qry.exec())
    {
        QMessageBox::critical(this, tr("Save"), tr("Information inserted"));
       ui->lineEdit_User->clear();
       ui->lineEdit_Pass->clear();
       ui->lineEdit_UserID->clear();
       ui->lineEdit_Status->clear();
        connClose();
    }
else
{
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
}
}

void MainWindow::on_pushButton_Modify_clicked()
{
    QString user, pass, uid, status;
    user = ui->lineEdit_User->text();
    pass = ui->lineEdit_Pass->text();
    uid = ui->lineEdit_UserID->text();
    status = ui->lineEdit_Status->text();
    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
    qry.prepare("update students set user='"+user+"', pass='"+pass+"', userid='"+uid+"', status='"+status+"' where user='"+user+"'");

if (qry.exec())
    {
        QMessageBox::critical(this, tr("Updated"), tr("Information updated"));
       ui->lineEdit_User->clear();
       ui->lineEdit_Pass->clear();
       ui->lineEdit_UserID->clear();
       ui->lineEdit_Status->clear();
        connClose();
    }
else
{
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
}
}

void MainWindow::on_pushButton_Remove_clicked()
{
    QString user, pass, uid, status;
   // user = ui->lineEdit_User->text();
  //  pass = ui->lineEdit_Pass->text();
    uid = ui->lineEdit_UserID->text();
   // status = ui->lineEdit_Status->text();
    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
    qry.prepare("delete from students where userid='"+uid+"'");

if (qry.exec())
    {
        QMessageBox::critical(this, tr("Remove"), tr("Information removed"));
       ui->lineEdit_User->clear();
       ui->lineEdit_Pass->clear();
       ui->lineEdit_UserID->clear();
       ui->lineEdit_Status->clear();
        connClose();
    }
    else
    {
        QMessageBox::critical(this, tr("Error"), qry.lastError().text());
    }
}

void MainWindow::on_pushButton_3_clicked()
{
    QSqlQueryModel * model2 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    qry->prepare("select user from students");
    qry->exec();

    model2->setQuery(*qry);
  //  ui->listView->setModel(model2);
     ui->comboBox->setModel(model2);
    connClose();
    qDebug() << (model2->rowCount());
}

void MainWindow::on_comboBox_currentIndexChanged(const QString &arg1)
{
    QString name =ui->comboBox->currentText();


    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
    qry.prepare("select * from students where user='"+name+"'");

if (qry.exec())
    {
        while(qry.next())
        {
            ui->lineEdit_User->setText(qry.value(0).toString());
            ui->lineEdit_Pass->setText(qry.value(1).toString());
            ui->lineEdit_UserID->setText(qry.value(2).toString());
            ui->lineEdit_Status->setText(qry.value(3).toString());
        }
        connClose();
    }
    else
    {
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
    }


}

void MainWindow::on_pushButton_Clear_clicked()
{
    ui->lineEdit_User->clear();
    ui->lineEdit_Pass->clear();
    ui->lineEdit_UserID->clear();
    ui->lineEdit_Status->clear();
}
