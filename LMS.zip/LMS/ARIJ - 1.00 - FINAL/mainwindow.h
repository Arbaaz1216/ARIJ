#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    void connClose()
    {
        myDB.close();
        myDB.removeDatabase(QSqlDatabase::defaultConnection);
    }
    bool connOpen()
    {
        myDB = QSqlDatabase::addDatabase("QSQLITE");
        myDB.setDatabaseName("C:/sqlite2/LMSNew.db");

        if(!myDB.open())
        {
           qDebug() << "Database failed to open.";
           return false;
        }
        else
        {
            qDebug() << "DB opened.";
            return true;
        }
    }
    QSqlDatabase myDB;

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_Admin_clicked();

    void on_pushButton_Student_clicked();

    void on_pushButton_Return_clicked();

    void on_pushButton_Return_2_clicked();


    void on_pushButton_AdminLogin_clicked();

    void on_pushButton_clicked();


    void on_pushButton_StudLogin_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_StudLogout_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_GPA_clicked();

    void ClearAll();
    void on_pushButton_2_clicked();

    void on_pushButton_Manage_clicked();

    void on_pushButton_Save_clicked();

    void on_pushButton_Modify_clicked();

    void on_pushButton_Remove_clicked();

    void on_pushButton_3_clicked();

    void on_comboBox_currentIndexChanged(const QString &arg1);

    void on_pushButton_Clear_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_manageCourse_clicked();

    void on_pushButton_load_2_clicked();

    void on_pushButton_save_2_clicked();

    void on_pushButton_clear2_clicked();

    void on_comboBox_2_currentIndexChanged(const QString &arg1);

    void on_pushButton_Remove_2_clicked();

    void on_pushButton_manageGrades_clicked();

    void on_pushButton_load_3_clicked();

    void on_comboBox_3_currentIndexChanged(const QString &arg1);

private:
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
