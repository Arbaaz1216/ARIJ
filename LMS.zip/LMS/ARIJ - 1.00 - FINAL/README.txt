Welcome to our Learning Management System.

To begin you run the program in QT by clicking the ARIJ.pro file.

You will be prompted to choose Admin or Student

Admin login
Admin Username: admin
Admin Password: pass 

An example of a student login
Student Username: 900745839
Student Password: mypass