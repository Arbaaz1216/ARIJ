#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <fstream>
#include <iostream>
#include <string>
#include <QFile>
#include <QTextStream>

QString userPt;
QString CurrentID;

using namespace std;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    if(!connOpen())
    {
        ui->label_15->setText("Failed");
    }
    else
    {
        ui->label_15->setText("");
    }


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_Admin_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(1);
}

void MainWindow::on_pushButton_Student_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(2);
}

void MainWindow::on_pushButton_Return_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_Return_2_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_AdminLogin_clicked()
{
        QString username_admin, password_admin;
        username_admin = ui->lineEdit_AdminLogin->text();
        password_admin = ui->lineEdit_AdminPass->text();

        if(!connOpen())
        {
            qDebug() << "Database failed to open.";
            return;
        }

        connOpen();

        QSqlQuery qry;
        qry.prepare("select * from admin where user = '"+username_admin+"' and pass = '"+password_admin+"' ");

   if (qry.exec())
        {
            int count = 0;

            while(qry.next())
            {
                count++;
            }

            if(count ==1)
            {
                connClose();
                QMessageBox::information(this, "Login File", "You have logged in as admin.");
                   ui->stackedWidget_Main->setCurrentIndex(3);
            }
           else if(count >1)
            {
                qDebug() << "Duplicate";
            }
          else  if(count < 1)
            {
                QMessageBox::warning(this, "Login", "Incorrect username and password.");
            }
        }


        ui->lineEdit_AdminLogin->clear();
        ui->lineEdit_AdminPass->clear();
}

void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_StudLogin_clicked()
{
    QString username_stu, password_stu;
    username_stu = ui->lineEdit_StudLogin->text();
    password_stu = ui->lineEdit_StudPass->text();

    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
    qry.prepare("select * from studinfo where stuid = '"+username_stu+"' and password = '"+password_stu+"' ");

if (qry.exec())
    {
        int count = 0;

        while(qry.next())
        {
            count++;
        }

        if(count ==1)
        {
            QMessageBox::information(this, "Login File", "You have logged in.");
            connClose();
               ui->stackedWidget_Main->setCurrentIndex(4);
               QFile fileWelcome("data\\StudentWelcome.txt");
                if(!fileWelcome.open(QIODevice::ReadOnly))
                    QMessageBox::information(0, "info", fileWelcome.errorString());

                QTextStream in(&fileWelcome);
               ui->textBrowser->setText(in.readAll());
               //ui->label_13->setText(username_stu);
              // QString IDString = QString::number(id);
               ui->label_ID->setText(username_stu);
        }
       else if(count >1)
        {
            qDebug() << "Duplicate";
        }
      else  if(count < 1)
        {
            QMessageBox::warning(this, "Login", "Incorrect username and password.");
        }
    }

userPt = username_stu;
    ui->lineEdit_StudLogin->clear();
    ui->lineEdit_StudPass->clear();
}

//display courses
void MainWindow::on_pushButton_6_clicked()
{
   // MainWindow conn;
    ui->stackedWidget_2->setCurrentIndex(1);

    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();

    QSqlQuery* qry = new QSqlQuery(this->myDB);


    qry->prepare("select cName as Courses from '"+userPt+"' ");

    qry->exec();

    model->setQuery(*qry);
    ui->tableView->setModel(model);
    connClose();
    qDebug() << (model->rowCount());
}

void MainWindow::on_pushButton_StudLogout_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
        ClearAll();
}

void MainWindow::on_pushButton_8_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(0);
    ui->label_GPA->clear();
}
//display grades
void MainWindow::on_pushButton_7_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(2);

    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();

    QSqlQuery* qry = new QSqlQuery(this->myDB);

    qry->prepare("select cName as Courses, cAvg as Grades, t1 as Test1, t2 as Test2,t3 as Test3, t4 as Test4 from '"+userPt+"'");

    qry->exec();

    model->setQuery(*qry);
    ui->tableView_3->setModel(model);
    connClose();
    qDebug() << (model->rowCount());

}

void MainWindow::on_pushButton_GPA_clicked()
{
    QString gpa;


    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
   // qry.prepare("select gpa from studinfo where stuid='"+userPt+"'");
    qry.prepare("select cName as Courses, cAvg as Grades, t1 as Test1, t2 as Test2,t3 as Test3, t4 as Test4 from '"+userPt+"'");

    QString g1;
    QString g2;
    string gr[4];
    int n[4];
if (qry.exec())
    {
        while(qry.next())
        {
            g1 = qry.value(0).toString();
           // ui->label_GPA->setText(qry.value(0).toString());
          /*  g[0] = qry.value(0).toString();
            g[1] = qry.value(1).toString();
            g[2] = qry.value(2).toString();
            g[3] = qry.value(3).toString();

            gr[0] = g[0].toStdString();
             gr[1] = g[1].toStdString();
              gr[2] = g[2].toStdString();
               gr[3] = g[3].toStdString();
*/
               /* if(gr[0] == "A")
                {
                     n[0] = 3;
                 }
                else
                {
                    n[0] = 10;
                }*/
           // int total= n[0] + n[1] + n[2] + n[3];

           // QString x = QString::number(total);
            // QString x = QString::number(n[2]);
         //   ui->label_GPA->setText(qry.value(1).toString());
            ui->label_GPA->setText("NULL");

        }
        connClose();
    }
    else
    {
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
    }
}

void MainWindow::ClearAll()
{
    ui->label_GPA->clear();
}

//display student info
void MainWindow::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    QSqlQueryModel * model2 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);

    qry->prepare("select name as Student, stuid as ID, password as Password, status as Standing, gpa as GPA from studinfo");
    qry->exec();

    model2->setQuery(*qry);
    ui->tableView_2->setModel(model2);
    connClose();
    qDebug() << (model2->rowCount());
}

void MainWindow::on_pushButton_Manage_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}
//register
void MainWindow::on_pushButton_Save_clicked()
{
    QString user_reg, pass_reg, uid_reg, status_reg;
    user_reg = ui->lineEdit_User->text();
    pass_reg = ui->lineEdit_Pass->text();
    uid_reg = ui->lineEdit_UserID->text();
    status_reg = ui->lineEdit_Status->text();

    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;

     qry.prepare("insert into studinfo (name, password, stuid, status) values('"+user_reg+"','"+pass_reg+"','"+uid_reg+"','"+status_reg+"')");

if (qry.exec())
    {
        QMessageBox::critical(this, tr("Save"), tr("Information inserted"));
       ui->lineEdit_User->clear();
       ui->lineEdit_Pass->clear();
       ui->lineEdit_UserID->clear();
       ui->lineEdit_Status->clear();
        connClose();
    }
else
{
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
}
}

void MainWindow::on_pushButton_Modify_clicked()
{
    QString user_mod, pass_mod, uid_mod, status_mod;
    user_mod = ui->lineEdit_User->text();
    pass_mod = ui->lineEdit_Pass->text();
    uid_mod = ui->lineEdit_UserID->text();
    status_mod = ui->lineEdit_Status->text();
    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;

    qry.prepare("update studinfo set name='"+user_mod+"', password='"+pass_mod+"', stuid='"+uid_mod+"', status='"+status_mod+"' where name='"+user_mod+"'");

if (qry.exec())
    {
        QMessageBox::critical(this, tr("Updated"), tr("Information updated"));
       ui->lineEdit_User->clear();
       ui->lineEdit_Pass->clear();
       ui->lineEdit_UserID->clear();
       ui->lineEdit_Status->clear();
        connClose();
    }
else
{
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
}
}

void MainWindow::on_pushButton_Remove_clicked()
{
    QString user_del, pass_del, uid_del, status_del;

    uid_del = ui->lineEdit_User_Remove->text();

    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;

    qry.prepare("delete from studinfo where stuid='"+uid_del+"'");

if (qry.exec())
    {
        QMessageBox::critical(this, tr("Remove"), tr("Information removed"));
       ui->lineEdit_User->clear();
       ui->lineEdit_Pass->clear();
       ui->lineEdit_UserID->clear();
       ui->lineEdit_Status->clear();
       ui->lineEdit_User_Remove->clear();
        connClose();
    }
    else
    {
        QMessageBox::critical(this, tr("Error"), qry.lastError().text());
    }

}

void MainWindow::on_pushButton_3_clicked()
{
    QSqlQueryModel * model2 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    qry->prepare("select name from studinfo");
    qry->exec();

    model2->setQuery(*qry);
     ui->comboBox->setModel(model2);
    connClose();
    qDebug() << (model2->rowCount());
}

void MainWindow::on_comboBox_currentIndexChanged(const QString &arg1)
{
    QString name =ui->comboBox->currentText();


    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
    qry.prepare("select * from studinfo where name='"+name+"'");

if (qry.exec())
    {
        while(qry.next())
        {
            ui->lineEdit_User->setText(qry.value(0).toString());
            ui->lineEdit_Pass->setText(qry.value(2).toString());
            ui->lineEdit_UserID->setText(qry.value(1).toString());
            ui->lineEdit_Status->setText(qry.value(3).toString());
        }
        connClose();
    }
    else
    {
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
    }
}

void MainWindow::on_pushButton_Clear_clicked()
{
    ui->lineEdit_User->clear();
    ui->lineEdit_Pass->clear();
    ui->lineEdit_UserID->clear();
    ui->lineEdit_Status->clear();
}
//view courses as admin
void MainWindow::on_pushButton_4_clicked()
{
    // MainWindow conn;
     ui->stackedWidget->setCurrentIndex(3);

     QSqlQueryModel * model = new QSqlQueryModel();
     connOpen();

     QSqlQuery* qry = new QSqlQuery(this->myDB);

     qry->prepare("select cName from a900384055");

     qry->exec();

     model->setQuery(*qry);
     ui->tableView_4->setModel(model);
     connClose();
     qDebug() << (model->rowCount());
}

void MainWindow::on_pushButton_manageCourse_clicked()
{
     ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_pushButton_load_2_clicked()
{
    QSqlQueryModel * model3 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    qry->prepare("select name from courseinfo");
    qry->exec();

    model3->setQuery(*qry);
     ui->comboBox_2->setModel(model3);
    connClose();
    qDebug() << (model3->rowCount());
}

void MainWindow::on_pushButton_save_2_clicked()
{
    QString course_name, course_id, course_subj, course_stat;
    course_name = ui->lineEdit_courseN->text();
    course_id = ui->lineEdit_courseID->text();
   course_subj = ui->lineEdit_courseSubj->text();
    course_stat = ui->lineEdit_courseMeet->text();

    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
     qry.prepare("insert into courseinfo (name, courseid, subject, status) values('"+course_name+"','"+course_id+"','"+course_subj+"','"+course_stat+"')");

if (qry.exec())
    {
        QMessageBox::critical(this, tr("Save"), tr("Information inserted"));
       ui->lineEdit_courseN->clear();
       ui->lineEdit_courseID->clear();
       ui->lineEdit_courseSubj->clear();
       ui->lineEdit_courseMeet->clear();
        connClose();
    }
else
{
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
}
}

void MainWindow::on_pushButton_clear2_clicked()
{
    {
        ui->lineEdit_courseN->clear();
        ui->lineEdit_courseID->clear();
        ui->lineEdit_courseMeet->clear();
        ui->lineEdit_courseSubj->clear();
    }
}

void MainWindow::on_comboBox_2_currentIndexChanged(const QString &arg1)
{
    QString name =ui->comboBox_2->currentText();


    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
    qry.prepare("select * from courseinfo where name='"+name+"'");

if (qry.exec())
    {
        while(qry.next())
        {
            ui->lineEdit_courseN->setText(qry.value(0).toString());
            ui->lineEdit_courseID->setText(qry.value(2).toString());
            ui->lineEdit_courseSubj->setText(qry.value(1).toString());
            ui->lineEdit_courseMeet->setText(qry.value(3).toString());
        }
        connClose();
    }
    else
    {
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
    }
}

void MainWindow::on_pushButton_Remove_2_clicked()
{
    QString courseN_del, courseID_del, courseSubj_del, courseStatus_del;
    courseN_del = ui->lineEdit_User_Remove_2->text();
    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
       qry.prepare("delete from courseinfo where name='"+courseN_del+"'");

if (qry.exec())
    {
        QMessageBox::critical(this, tr("Remove"), tr("Information removed"));
       ui->lineEdit_courseN->clear();
       ui->lineEdit_courseID->clear();
       ui->lineEdit_courseSubj->clear();
       ui->lineEdit_courseMeet->clear();
       ui->lineEdit_User_Remove_2->clear();
        connClose();
    }
    else
    {
        QMessageBox::critical(this, tr("Error"), qry.lastError().text());
    }

}

void MainWindow::on_pushButton_manageGrades_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);

    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();

    QSqlQuery* qry = new QSqlQuery(this->myDB);

    qry->prepare("select cName as Courses, cAvg as Grades, t1 as Test1, t2 as Test2,t3 as Test3, t4 as Test4 from '"+userPt+"'");

    qry->exec();

    model->setQuery(*qry);
    ui->tableView_m->setModel(model);
    connClose();
    qDebug() << (model->rowCount());
}

void MainWindow::on_pushButton_load_3_clicked()
{

    QSqlQueryModel * model4 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    qry->prepare("select stuid from studinfo");
    qry->exec();

    model4->setQuery(*qry);
      ui->comboBox_3->setModel(model4);
    connClose();
    qDebug() << (model4->rowCount());
}

void MainWindow::on_comboBox_3_currentIndexChanged(const QString &arg1)
{
    QString studentID =ui->comboBox_3->currentText();


    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
   qry.prepare("select t1, t2 ,t3, t4 from '"+studentID+"'");


if (qry.exec())
    {
        while(qry.next())
        {
            ui->lineEdit_t1->setText(qry.value(0).toString());
            ui->lineEdit_t2->setText(qry.value(1).toString());
            ui->lineEdit_t3->setText(qry.value(2).toString());
            ui->lineEdit_t4->setText(qry.value(3).toString());
            CurrentID = studentID;
        }
        connClose();
    }
    else
    {
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
    }


QSqlQueryModel * model = new QSqlQueryModel();
connOpen();

QSqlQuery* qry1 = new QSqlQuery(this->myDB);

qry1->prepare("select cName as Courses, cAvg as Grades, t1 as Test1, t2 as Test2,t3 as Test3, t4 as Test4 from '"+studentID+"'");

qry1->exec();

model->setQuery(*qry1);
ui->tableView_m->setModel(model);
CurrentID = studentID;
connClose();
}


