/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout;
    QStackedWidget *stackedWidget_Main;
    QWidget *page_0_Main;
    QPushButton *pushButton_Student;
    QLabel *label_UHD;
    QPushButton *pushButton_Admin;
    QLabel *label_ARIJ;
    QLabel *label_Copyright;
    QWidget *page_1_AdminLogin;
    QLabel *label_Admin_Login;
    QPushButton *pushButton_Admin_Return;
    QLineEdit *lineEdit_Admin_Login;
    QLineEdit *lineEdit_Admin_Pass;
    QLabel *label_Username;
    QLabel *label_PW;
    QPushButton *pushButton_Admin_Login;
    QLabel *label_Forgot_PW;
    QLabel *label_Server_Status;
    QWidget *page_2_StudentLogin;
    QLabel *label_Student_Login;
    QPushButton *pushButton_Student_Return;
    QLineEdit *lineEdit_Student_Login;
    QLabel *label_Password_2;
    QLabel *label_Username_2;
    QLineEdit *lineEdit_Student_Pass;
    QPushButton *pushButton_Student_Login;
    QLabel *label_Forgot_PW_2;
    QWidget *page_AdminPanel;
    QLabel *label_AdminPanel;
    QPushButton *pushButton_Admin_Logout;
    QPushButton *pushButton_View_Students;
    QPushButton *pushButton_Manage_Students;
    QStackedWidget *stackedWidget_AdminPanel;
    QWidget *page_0_Admin_Panel;
    QLabel *label_Admin_Welcome;
    QWidget *page_1_View_Students;
    QTableView *tableView_Display_Students;
    QWidget *page_2_Manage_Students;
    QGroupBox *groupBox_Manage_Students;
    QVBoxLayout *verticalLayout;
    QLabel *label_M_User;
    QLineEdit *lineEdit_Stu_User;
    QLabel *label_M_Pass;
    QLineEdit *lineEdit_Stu_Password;
    QLabel *label_M_UserID;
    QLineEdit *lineEdit_Stu_UserID;
    QLabel *label_M_Status;
    QLineEdit *lineEdit_Stu_Status;
    QPushButton *pushButton_Student_Register;
    QPushButton *pushButton_Student_Modify;
    QPushButton *pushButton_Student_Load;
    QComboBox *comboBox_Load_Students;
    QPushButton *pushButton_Student_Clear;
    QGroupBox *groupBox_DeleteStudent;
    QPushButton *pushButton_Student_Remove;
    QLineEdit *lineEdit_Student_Remove;
    QLabel *label_StudentID;
    QWidget *page_3_ManageCourses;
    QGroupBox *groupBox_M_Courses;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_M_Courses;
    QLineEdit *lineEdit_courseN;
    QLabel *label_M_CourseID;
    QLineEdit *lineEdit_courseID;
    QLabel *label_M_Subj;
    QLineEdit *lineEdit_courseSubj;
    QLabel *label_M_Meeting;
    QLineEdit *lineEdit_courseMeet;
    QGroupBox *groupBox_Delete_Courses;
    QPushButton *pushButton_Course_Remove;
    QLineEdit *lineEdit_Course_Remove;
    QLabel *label_Delete_Course;
    QLabel *label_Student_Name;
    QPushButton *pushButton_Course_Register;
    QPushButton *pushButton_Course_Load;
    QComboBox *comboBox_Load_Courses;
    QPushButton *pushButton_Course_Clear;
    QPushButton *pushButton_Course_Modify;
    QPushButton *pushButton_Add_Student;
    QLineEdit *lineEdit_Student_MCourse;
    QPushButton *pushButton_Load_Student_MCourse;
    QComboBox *comboBox_Load_Student_MCourse;
    QWidget *page_4_Manage_Grades;
    QPushButton *pushButton_Load_Student_Grades;
    QComboBox *comboBox_Load_Student_Grades;
    QLineEdit *lineEdit_test1;
    QLineEdit *lineEdit_test2;
    QLineEdit *lineEdit_test3;
    QLineEdit *lineEdit_test4;
    QLabel *label_test1;
    QLabel *label_test2;
    QLabel *label_test3;
    QLabel *label_test4;
    QComboBox *comboBox_Load_Student_Course;
    QPushButton *pushButton_Load_Student_Course;
    QLabel *label_Welcome_Grades;
    QLabel *label_Welcome_Instructions;
    QPushButton *pushButton_Student_Add_Grade;
    QPushButton *pushButton_Student_Modify_grade;
    QTableView *tableView_Display_Grades;
    QWidget *page_5_View_Courses;
    QTableView *tableView_View_Courses;
    QPushButton *pushButton_Manage_Courses;
    QPushButton *pushButton_Manage_Grades;
    QPushButton *pushButton_View_Courses;
    QWidget *page_5_StudentPanel;
    QPushButton *pushButton_Student_View_Courses;
    QPushButton *pushButton_Student_View_Grades;
    QPushButton *pushButton_Student_Logout;
    QStackedWidget *stackedWidget_StudentPanel;
    QWidget *page_0_Student_Panel;
    QLabel *label_Stu_Announcement;
    QTextBrowser *textBrowser_Stu_Announcement;
    QLabel *label_Stu_Welcome;
    QWidget *page_1_Student_View_Courses;
    QTableView *tableView_Student_View_Courses;
    QLabel *label_My_Courses;
    QWidget *page_2_Student_View_Grades;
    QPushButton *pushButton_Student_Calculate_GPA;
    QLabel *label_Student_GPA;
    QTableView *tableView_Student_View_Grades;
    QLabel *label_My_Grades;
    QPushButton *pushButton_Student_MainMenu;
    QLabel *label_StudentPanel;
    QLabel *label_Display_StudentID;
    QLabel *label_Student_ID;
    QLabel *label_Name;
    QLabel *label_Display_Name;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        MainWindow->setMinimumSize(QSize(800, 600));
        MainWindow->setMaximumSize(QSize(800, 600));
        MainWindow->setWindowOpacity(1.000000000000000);
        MainWindow->setAutoFillBackground(false);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        horizontalLayout = new QHBoxLayout(centralWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        stackedWidget_Main = new QStackedWidget(centralWidget);
        stackedWidget_Main->setObjectName(QString::fromUtf8("stackedWidget_Main"));
        page_0_Main = new QWidget();
        page_0_Main->setObjectName(QString::fromUtf8("page_0_Main"));
        pushButton_Student = new QPushButton(page_0_Main);
        pushButton_Student->setObjectName(QString::fromUtf8("pushButton_Student"));
        pushButton_Student->setGeometry(QRect(320, 170, 171, 23));
        label_UHD = new QLabel(page_0_Main);
        label_UHD->setObjectName(QString::fromUtf8("label_UHD"));
        label_UHD->setGeometry(QRect(310, 250, 200, 191));
        label_UHD->setPixmap(QPixmap(QString::fromUtf8(":/images/images/gator.png")));
        pushButton_Admin = new QPushButton(page_0_Main);
        pushButton_Admin->setObjectName(QString::fromUtf8("pushButton_Admin"));
        pushButton_Admin->setGeometry(QRect(320, 140, 171, 23));
        label_ARIJ = new QLabel(page_0_Main);
        label_ARIJ->setObjectName(QString::fromUtf8("label_ARIJ"));
        label_ARIJ->setGeometry(QRect(10, 0, 761, 131));
        label_Copyright = new QLabel(page_0_Main);
        label_Copyright->setObjectName(QString::fromUtf8("label_Copyright"));
        label_Copyright->setGeometry(QRect(340, 450, 129, 13));
        stackedWidget_Main->addWidget(page_0_Main);
        page_1_AdminLogin = new QWidget();
        page_1_AdminLogin->setObjectName(QString::fromUtf8("page_1_AdminLogin"));
        label_Admin_Login = new QLabel(page_1_AdminLogin);
        label_Admin_Login->setObjectName(QString::fromUtf8("label_Admin_Login"));
        label_Admin_Login->setGeometry(QRect(290, 90, 181, 21));
        pushButton_Admin_Return = new QPushButton(page_1_AdminLogin);
        pushButton_Admin_Return->setObjectName(QString::fromUtf8("pushButton_Admin_Return"));
        pushButton_Admin_Return->setGeometry(QRect(10, 500, 75, 23));
        lineEdit_Admin_Login = new QLineEdit(page_1_AdminLogin);
        lineEdit_Admin_Login->setObjectName(QString::fromUtf8("lineEdit_Admin_Login"));
        lineEdit_Admin_Login->setGeometry(QRect(300, 140, 181, 21));
        lineEdit_Admin_Pass = new QLineEdit(page_1_AdminLogin);
        lineEdit_Admin_Pass->setObjectName(QString::fromUtf8("lineEdit_Admin_Pass"));
        lineEdit_Admin_Pass->setGeometry(QRect(300, 190, 181, 21));
        lineEdit_Admin_Pass->setEchoMode(QLineEdit::Password);
        label_Username = new QLabel(page_1_AdminLogin);
        label_Username->setObjectName(QString::fromUtf8("label_Username"));
        label_Username->setGeometry(QRect(300, 120, 91, 16));
        label_PW = new QLabel(page_1_AdminLogin);
        label_PW->setObjectName(QString::fromUtf8("label_PW"));
        label_PW->setGeometry(QRect(300, 170, 71, 16));
        pushButton_Admin_Login = new QPushButton(page_1_AdminLogin);
        pushButton_Admin_Login->setObjectName(QString::fromUtf8("pushButton_Admin_Login"));
        pushButton_Admin_Login->setGeometry(QRect(350, 220, 75, 23));
        label_Forgot_PW = new QLabel(page_1_AdminLogin);
        label_Forgot_PW->setObjectName(QString::fromUtf8("label_Forgot_PW"));
        label_Forgot_PW->setGeometry(QRect(350, 260, 111, 16));
        label_Server_Status = new QLabel(page_1_AdminLogin);
        label_Server_Status->setObjectName(QString::fromUtf8("label_Server_Status"));
        label_Server_Status->setGeometry(QRect(690, 0, 211, 16));
        stackedWidget_Main->addWidget(page_1_AdminLogin);
        page_2_StudentLogin = new QWidget();
        page_2_StudentLogin->setObjectName(QString::fromUtf8("page_2_StudentLogin"));
        label_Student_Login = new QLabel(page_2_StudentLogin);
        label_Student_Login->setObjectName(QString::fromUtf8("label_Student_Login"));
        label_Student_Login->setGeometry(QRect(320, 90, 131, 20));
        pushButton_Student_Return = new QPushButton(page_2_StudentLogin);
        pushButton_Student_Return->setObjectName(QString::fromUtf8("pushButton_Student_Return"));
        pushButton_Student_Return->setGeometry(QRect(10, 500, 75, 23));
        lineEdit_Student_Login = new QLineEdit(page_2_StudentLogin);
        lineEdit_Student_Login->setObjectName(QString::fromUtf8("lineEdit_Student_Login"));
        lineEdit_Student_Login->setGeometry(QRect(300, 140, 181, 21));
        label_Password_2 = new QLabel(page_2_StudentLogin);
        label_Password_2->setObjectName(QString::fromUtf8("label_Password_2"));
        label_Password_2->setGeometry(QRect(300, 170, 61, 16));
        label_Username_2 = new QLabel(page_2_StudentLogin);
        label_Username_2->setObjectName(QString::fromUtf8("label_Username_2"));
        label_Username_2->setGeometry(QRect(300, 120, 47, 13));
        lineEdit_Student_Pass = new QLineEdit(page_2_StudentLogin);
        lineEdit_Student_Pass->setObjectName(QString::fromUtf8("lineEdit_Student_Pass"));
        lineEdit_Student_Pass->setGeometry(QRect(300, 190, 181, 21));
        lineEdit_Student_Pass->setEchoMode(QLineEdit::Password);
        pushButton_Student_Login = new QPushButton(page_2_StudentLogin);
        pushButton_Student_Login->setObjectName(QString::fromUtf8("pushButton_Student_Login"));
        pushButton_Student_Login->setGeometry(QRect(350, 220, 75, 23));
        label_Forgot_PW_2 = new QLabel(page_2_StudentLogin);
        label_Forgot_PW_2->setObjectName(QString::fromUtf8("label_Forgot_PW_2"));
        label_Forgot_PW_2->setGeometry(QRect(340, 260, 111, 16));
        stackedWidget_Main->addWidget(page_2_StudentLogin);
        page_AdminPanel = new QWidget();
        page_AdminPanel->setObjectName(QString::fromUtf8("page_AdminPanel"));
        label_AdminPanel = new QLabel(page_AdminPanel);
        label_AdminPanel->setObjectName(QString::fromUtf8("label_AdminPanel"));
        label_AdminPanel->setGeometry(QRect(370, 10, 191, 31));
        pushButton_Admin_Logout = new QPushButton(page_AdminPanel);
        pushButton_Admin_Logout->setObjectName(QString::fromUtf8("pushButton_Admin_Logout"));
        pushButton_Admin_Logout->setGeometry(QRect(10, 490, 75, 23));
        pushButton_View_Students = new QPushButton(page_AdminPanel);
        pushButton_View_Students->setObjectName(QString::fromUtf8("pushButton_View_Students"));
        pushButton_View_Students->setGeometry(QRect(20, 50, 121, 23));
        pushButton_Manage_Students = new QPushButton(page_AdminPanel);
        pushButton_Manage_Students->setObjectName(QString::fromUtf8("pushButton_Manage_Students"));
        pushButton_Manage_Students->setGeometry(QRect(20, 80, 121, 23));
        stackedWidget_AdminPanel = new QStackedWidget(page_AdminPanel);
        stackedWidget_AdminPanel->setObjectName(QString::fromUtf8("stackedWidget_AdminPanel"));
        stackedWidget_AdminPanel->setGeometry(QRect(150, 40, 621, 501));
        page_0_Admin_Panel = new QWidget();
        page_0_Admin_Panel->setObjectName(QString::fromUtf8("page_0_Admin_Panel"));
        label_Admin_Welcome = new QLabel(page_0_Admin_Panel);
        label_Admin_Welcome->setObjectName(QString::fromUtf8("label_Admin_Welcome"));
        label_Admin_Welcome->setGeometry(QRect(40, 40, 481, 81));
        stackedWidget_AdminPanel->addWidget(page_0_Admin_Panel);
        page_1_View_Students = new QWidget();
        page_1_View_Students->setObjectName(QString::fromUtf8("page_1_View_Students"));
        tableView_Display_Students = new QTableView(page_1_View_Students);
        tableView_Display_Students->setObjectName(QString::fromUtf8("tableView_Display_Students"));
        tableView_Display_Students->setGeometry(QRect(30, 10, 571, 451));
        stackedWidget_AdminPanel->addWidget(page_1_View_Students);
        page_2_Manage_Students = new QWidget();
        page_2_Manage_Students->setObjectName(QString::fromUtf8("page_2_Manage_Students"));
        groupBox_Manage_Students = new QGroupBox(page_2_Manage_Students);
        groupBox_Manage_Students->setObjectName(QString::fromUtf8("groupBox_Manage_Students"));
        groupBox_Manage_Students->setGeometry(QRect(80, 50, 411, 241));
        verticalLayout = new QVBoxLayout(groupBox_Manage_Students);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_M_User = new QLabel(groupBox_Manage_Students);
        label_M_User->setObjectName(QString::fromUtf8("label_M_User"));

        verticalLayout->addWidget(label_M_User);

        lineEdit_Stu_User = new QLineEdit(groupBox_Manage_Students);
        lineEdit_Stu_User->setObjectName(QString::fromUtf8("lineEdit_Stu_User"));

        verticalLayout->addWidget(lineEdit_Stu_User);

        label_M_Pass = new QLabel(groupBox_Manage_Students);
        label_M_Pass->setObjectName(QString::fromUtf8("label_M_Pass"));

        verticalLayout->addWidget(label_M_Pass);

        lineEdit_Stu_Password = new QLineEdit(groupBox_Manage_Students);
        lineEdit_Stu_Password->setObjectName(QString::fromUtf8("lineEdit_Stu_Password"));

        verticalLayout->addWidget(lineEdit_Stu_Password);

        label_M_UserID = new QLabel(groupBox_Manage_Students);
        label_M_UserID->setObjectName(QString::fromUtf8("label_M_UserID"));

        verticalLayout->addWidget(label_M_UserID);

        lineEdit_Stu_UserID = new QLineEdit(groupBox_Manage_Students);
        lineEdit_Stu_UserID->setObjectName(QString::fromUtf8("lineEdit_Stu_UserID"));

        verticalLayout->addWidget(lineEdit_Stu_UserID);

        label_M_Status = new QLabel(groupBox_Manage_Students);
        label_M_Status->setObjectName(QString::fromUtf8("label_M_Status"));

        verticalLayout->addWidget(label_M_Status);

        lineEdit_Stu_Status = new QLineEdit(groupBox_Manage_Students);
        lineEdit_Stu_Status->setObjectName(QString::fromUtf8("lineEdit_Stu_Status"));

        verticalLayout->addWidget(lineEdit_Stu_Status);

        pushButton_Student_Register = new QPushButton(page_2_Manage_Students);
        pushButton_Student_Register->setObjectName(QString::fromUtf8("pushButton_Student_Register"));
        pushButton_Student_Register->setGeometry(QRect(80, 300, 101, 23));
        pushButton_Student_Modify = new QPushButton(page_2_Manage_Students);
        pushButton_Student_Modify->setObjectName(QString::fromUtf8("pushButton_Student_Modify"));
        pushButton_Student_Modify->setGeometry(QRect(190, 300, 75, 23));
        pushButton_Student_Load = new QPushButton(page_2_Manage_Students);
        pushButton_Student_Load->setObjectName(QString::fromUtf8("pushButton_Student_Load"));
        pushButton_Student_Load->setGeometry(QRect(270, 20, 75, 23));
        comboBox_Load_Students = new QComboBox(page_2_Manage_Students);
        comboBox_Load_Students->setObjectName(QString::fromUtf8("comboBox_Load_Students"));
        comboBox_Load_Students->setGeometry(QRect(360, 20, 121, 22));
        pushButton_Student_Clear = new QPushButton(page_2_Manage_Students);
        pushButton_Student_Clear->setObjectName(QString::fromUtf8("pushButton_Student_Clear"));
        pushButton_Student_Clear->setGeometry(QRect(400, 300, 75, 23));
        groupBox_DeleteStudent = new QGroupBox(page_2_Manage_Students);
        groupBox_DeleteStudent->setObjectName(QString::fromUtf8("groupBox_DeleteStudent"));
        groupBox_DeleteStudent->setGeometry(QRect(80, 340, 411, 101));
        pushButton_Student_Remove = new QPushButton(groupBox_DeleteStudent);
        pushButton_Student_Remove->setObjectName(QString::fromUtf8("pushButton_Student_Remove"));
        pushButton_Student_Remove->setGeometry(QRect(320, 70, 75, 23));
        lineEdit_Student_Remove = new QLineEdit(groupBox_DeleteStudent);
        lineEdit_Student_Remove->setObjectName(QString::fromUtf8("lineEdit_Student_Remove"));
        lineEdit_Student_Remove->setGeometry(QRect(10, 40, 391, 20));
        label_StudentID = new QLabel(groupBox_DeleteStudent);
        label_StudentID->setObjectName(QString::fromUtf8("label_StudentID"));
        label_StudentID->setGeometry(QRect(10, 20, 91, 16));
        stackedWidget_AdminPanel->addWidget(page_2_Manage_Students);
        page_3_ManageCourses = new QWidget();
        page_3_ManageCourses->setObjectName(QString::fromUtf8("page_3_ManageCourses"));
        groupBox_M_Courses = new QGroupBox(page_3_ManageCourses);
        groupBox_M_Courses->setObjectName(QString::fromUtf8("groupBox_M_Courses"));
        groupBox_M_Courses->setGeometry(QRect(70, 50, 411, 241));
        verticalLayout_2 = new QVBoxLayout(groupBox_M_Courses);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_M_Courses = new QLabel(groupBox_M_Courses);
        label_M_Courses->setObjectName(QString::fromUtf8("label_M_Courses"));

        verticalLayout_2->addWidget(label_M_Courses);

        lineEdit_courseN = new QLineEdit(groupBox_M_Courses);
        lineEdit_courseN->setObjectName(QString::fromUtf8("lineEdit_courseN"));

        verticalLayout_2->addWidget(lineEdit_courseN);

        label_M_CourseID = new QLabel(groupBox_M_Courses);
        label_M_CourseID->setObjectName(QString::fromUtf8("label_M_CourseID"));

        verticalLayout_2->addWidget(label_M_CourseID);

        lineEdit_courseID = new QLineEdit(groupBox_M_Courses);
        lineEdit_courseID->setObjectName(QString::fromUtf8("lineEdit_courseID"));

        verticalLayout_2->addWidget(lineEdit_courseID);

        label_M_Subj = new QLabel(groupBox_M_Courses);
        label_M_Subj->setObjectName(QString::fromUtf8("label_M_Subj"));

        verticalLayout_2->addWidget(label_M_Subj);

        lineEdit_courseSubj = new QLineEdit(groupBox_M_Courses);
        lineEdit_courseSubj->setObjectName(QString::fromUtf8("lineEdit_courseSubj"));

        verticalLayout_2->addWidget(lineEdit_courseSubj);

        label_M_Meeting = new QLabel(groupBox_M_Courses);
        label_M_Meeting->setObjectName(QString::fromUtf8("label_M_Meeting"));

        verticalLayout_2->addWidget(label_M_Meeting);

        lineEdit_courseMeet = new QLineEdit(groupBox_M_Courses);
        lineEdit_courseMeet->setObjectName(QString::fromUtf8("lineEdit_courseMeet"));

        verticalLayout_2->addWidget(lineEdit_courseMeet);

        groupBox_Delete_Courses = new QGroupBox(page_3_ManageCourses);
        groupBox_Delete_Courses->setObjectName(QString::fromUtf8("groupBox_Delete_Courses"));
        groupBox_Delete_Courses->setGeometry(QRect(70, 320, 411, 101));
        pushButton_Course_Remove = new QPushButton(groupBox_Delete_Courses);
        pushButton_Course_Remove->setObjectName(QString::fromUtf8("pushButton_Course_Remove"));
        pushButton_Course_Remove->setGeometry(QRect(320, 70, 75, 23));
        lineEdit_Course_Remove = new QLineEdit(groupBox_Delete_Courses);
        lineEdit_Course_Remove->setObjectName(QString::fromUtf8("lineEdit_Course_Remove"));
        lineEdit_Course_Remove->setGeometry(QRect(10, 40, 391, 20));
        label_Delete_Course = new QLabel(groupBox_Delete_Courses);
        label_Delete_Course->setObjectName(QString::fromUtf8("label_Delete_Course"));
        label_Delete_Course->setGeometry(QRect(10, 20, 121, 16));
        label_Student_Name = new QLabel(groupBox_Delete_Courses);
        label_Student_Name->setObjectName(QString::fromUtf8("label_Student_Name"));
        label_Student_Name->setGeometry(QRect(10, 80, 111, 16));
        pushButton_Course_Register = new QPushButton(page_3_ManageCourses);
        pushButton_Course_Register->setObjectName(QString::fromUtf8("pushButton_Course_Register"));
        pushButton_Course_Register->setGeometry(QRect(70, 290, 101, 23));
        pushButton_Course_Load = new QPushButton(page_3_ManageCourses);
        pushButton_Course_Load->setObjectName(QString::fromUtf8("pushButton_Course_Load"));
        pushButton_Course_Load->setGeometry(QRect(234, 20, 91, 23));
        comboBox_Load_Courses = new QComboBox(page_3_ManageCourses);
        comboBox_Load_Courses->setObjectName(QString::fromUtf8("comboBox_Load_Courses"));
        comboBox_Load_Courses->setGeometry(QRect(340, 20, 141, 22));
        pushButton_Course_Clear = new QPushButton(page_3_ManageCourses);
        pushButton_Course_Clear->setObjectName(QString::fromUtf8("pushButton_Course_Clear"));
        pushButton_Course_Clear->setGeometry(QRect(400, 290, 75, 23));
        pushButton_Course_Modify = new QPushButton(page_3_ManageCourses);
        pushButton_Course_Modify->setObjectName(QString::fromUtf8("pushButton_Course_Modify"));
        pushButton_Course_Modify->setGeometry(QRect(180, 290, 75, 23));
        pushButton_Add_Student = new QPushButton(page_3_ManageCourses);
        pushButton_Add_Student->setObjectName(QString::fromUtf8("pushButton_Add_Student"));
        pushButton_Add_Student->setGeometry(QRect(90, 450, 75, 23));
        lineEdit_Student_MCourse = new QLineEdit(page_3_ManageCourses);
        lineEdit_Student_MCourse->setObjectName(QString::fromUtf8("lineEdit_Student_MCourse"));
        lineEdit_Student_MCourse->setGeometry(QRect(80, 420, 391, 20));
        pushButton_Load_Student_MCourse = new QPushButton(page_3_ManageCourses);
        pushButton_Load_Student_MCourse->setObjectName(QString::fromUtf8("pushButton_Load_Student_MCourse"));
        pushButton_Load_Student_MCourse->setGeometry(QRect(180, 450, 91, 21));
        comboBox_Load_Student_MCourse = new QComboBox(page_3_ManageCourses);
        comboBox_Load_Student_MCourse->setObjectName(QString::fromUtf8("comboBox_Load_Student_MCourse"));
        comboBox_Load_Student_MCourse->setGeometry(QRect(290, 450, 121, 22));
        stackedWidget_AdminPanel->addWidget(page_3_ManageCourses);
        page_4_Manage_Grades = new QWidget();
        page_4_Manage_Grades->setObjectName(QString::fromUtf8("page_4_Manage_Grades"));
        pushButton_Load_Student_Grades = new QPushButton(page_4_Manage_Grades);
        pushButton_Load_Student_Grades->setObjectName(QString::fromUtf8("pushButton_Load_Student_Grades"));
        pushButton_Load_Student_Grades->setGeometry(QRect(20, 150, 91, 23));
        comboBox_Load_Student_Grades = new QComboBox(page_4_Manage_Grades);
        comboBox_Load_Student_Grades->setObjectName(QString::fromUtf8("comboBox_Load_Student_Grades"));
        comboBox_Load_Student_Grades->setGeometry(QRect(130, 150, 91, 22));
        lineEdit_test1 = new QLineEdit(page_4_Manage_Grades);
        lineEdit_test1->setObjectName(QString::fromUtf8("lineEdit_test1"));
        lineEdit_test1->setGeometry(QRect(30, 390, 101, 21));
        lineEdit_test2 = new QLineEdit(page_4_Manage_Grades);
        lineEdit_test2->setObjectName(QString::fromUtf8("lineEdit_test2"));
        lineEdit_test2->setGeometry(QRect(150, 390, 101, 20));
        lineEdit_test3 = new QLineEdit(page_4_Manage_Grades);
        lineEdit_test3->setObjectName(QString::fromUtf8("lineEdit_test3"));
        lineEdit_test3->setGeometry(QRect(270, 390, 113, 20));
        lineEdit_test4 = new QLineEdit(page_4_Manage_Grades);
        lineEdit_test4->setObjectName(QString::fromUtf8("lineEdit_test4"));
        lineEdit_test4->setGeometry(QRect(400, 390, 113, 20));
        label_test1 = new QLabel(page_4_Manage_Grades);
        label_test1->setObjectName(QString::fromUtf8("label_test1"));
        label_test1->setGeometry(QRect(60, 370, 47, 13));
        label_test2 = new QLabel(page_4_Manage_Grades);
        label_test2->setObjectName(QString::fromUtf8("label_test2"));
        label_test2->setGeometry(QRect(190, 370, 47, 13));
        label_test3 = new QLabel(page_4_Manage_Grades);
        label_test3->setObjectName(QString::fromUtf8("label_test3"));
        label_test3->setGeometry(QRect(300, 370, 47, 13));
        label_test4 = new QLabel(page_4_Manage_Grades);
        label_test4->setObjectName(QString::fromUtf8("label_test4"));
        label_test4->setGeometry(QRect(430, 370, 47, 13));
        comboBox_Load_Student_Course = new QComboBox(page_4_Manage_Grades);
        comboBox_Load_Student_Course->setObjectName(QString::fromUtf8("comboBox_Load_Student_Course"));
        comboBox_Load_Student_Course->setGeometry(QRect(440, 150, 81, 22));
        pushButton_Load_Student_Course = new QPushButton(page_4_Manage_Grades);
        pushButton_Load_Student_Course->setObjectName(QString::fromUtf8("pushButton_Load_Student_Course"));
        pushButton_Load_Student_Course->setGeometry(QRect(330, 150, 91, 23));
        label_Welcome_Grades = new QLabel(page_4_Manage_Grades);
        label_Welcome_Grades->setObjectName(QString::fromUtf8("label_Welcome_Grades"));
        label_Welcome_Grades->setGeometry(QRect(30, 10, 181, 41));
        label_Welcome_Instructions = new QLabel(page_4_Manage_Grades);
        label_Welcome_Instructions->setObjectName(QString::fromUtf8("label_Welcome_Instructions"));
        label_Welcome_Instructions->setGeometry(QRect(30, 40, 571, 21));
        pushButton_Student_Add_Grade = new QPushButton(page_4_Manage_Grades);
        pushButton_Student_Add_Grade->setObjectName(QString::fromUtf8("pushButton_Student_Add_Grade"));
        pushButton_Student_Add_Grade->setGeometry(QRect(30, 430, 75, 23));
        pushButton_Student_Modify_grade = new QPushButton(page_4_Manage_Grades);
        pushButton_Student_Modify_grade->setObjectName(QString::fromUtf8("pushButton_Student_Modify_grade"));
        pushButton_Student_Modify_grade->setGeometry(QRect(110, 430, 75, 23));
        tableView_Display_Grades = new QTableView(page_4_Manage_Grades);
        tableView_Display_Grades->setObjectName(QString::fromUtf8("tableView_Display_Grades"));
        tableView_Display_Grades->setGeometry(QRect(0, 190, 611, 171));
        stackedWidget_AdminPanel->addWidget(page_4_Manage_Grades);
        page_5_View_Courses = new QWidget();
        page_5_View_Courses->setObjectName(QString::fromUtf8("page_5_View_Courses"));
        tableView_View_Courses = new QTableView(page_5_View_Courses);
        tableView_View_Courses->setObjectName(QString::fromUtf8("tableView_View_Courses"));
        tableView_View_Courses->setGeometry(QRect(20, 20, 541, 391));
        stackedWidget_AdminPanel->addWidget(page_5_View_Courses);
        pushButton_Manage_Courses = new QPushButton(page_AdminPanel);
        pushButton_Manage_Courses->setObjectName(QString::fromUtf8("pushButton_Manage_Courses"));
        pushButton_Manage_Courses->setGeometry(QRect(20, 140, 121, 23));
        pushButton_Manage_Grades = new QPushButton(page_AdminPanel);
        pushButton_Manage_Grades->setObjectName(QString::fromUtf8("pushButton_Manage_Grades"));
        pushButton_Manage_Grades->setGeometry(QRect(20, 170, 121, 23));
        pushButton_View_Courses = new QPushButton(page_AdminPanel);
        pushButton_View_Courses->setObjectName(QString::fromUtf8("pushButton_View_Courses"));
        pushButton_View_Courses->setGeometry(QRect(20, 110, 121, 23));
        stackedWidget_Main->addWidget(page_AdminPanel);
        page_5_StudentPanel = new QWidget();
        page_5_StudentPanel->setObjectName(QString::fromUtf8("page_5_StudentPanel"));
        pushButton_Student_View_Courses = new QPushButton(page_5_StudentPanel);
        pushButton_Student_View_Courses->setObjectName(QString::fromUtf8("pushButton_Student_View_Courses"));
        pushButton_Student_View_Courses->setGeometry(QRect(20, 30, 111, 23));
        pushButton_Student_View_Grades = new QPushButton(page_5_StudentPanel);
        pushButton_Student_View_Grades->setObjectName(QString::fromUtf8("pushButton_Student_View_Grades"));
        pushButton_Student_View_Grades->setGeometry(QRect(140, 30, 111, 23));
        pushButton_Student_Logout = new QPushButton(page_5_StudentPanel);
        pushButton_Student_Logout->setObjectName(QString::fromUtf8("pushButton_Student_Logout"));
        pushButton_Student_Logout->setGeometry(QRect(690, 20, 75, 23));
        stackedWidget_StudentPanel = new QStackedWidget(page_5_StudentPanel);
        stackedWidget_StudentPanel->setObjectName(QString::fromUtf8("stackedWidget_StudentPanel"));
        stackedWidget_StudentPanel->setGeometry(QRect(20, 60, 751, 461));
        page_0_Student_Panel = new QWidget();
        page_0_Student_Panel->setObjectName(QString::fromUtf8("page_0_Student_Panel"));
        label_Stu_Announcement = new QLabel(page_0_Student_Panel);
        label_Stu_Announcement->setObjectName(QString::fromUtf8("label_Stu_Announcement"));
        label_Stu_Announcement->setGeometry(QRect(0, 110, 131, 16));
        textBrowser_Stu_Announcement = new QTextBrowser(page_0_Student_Panel);
        textBrowser_Stu_Announcement->setObjectName(QString::fromUtf8("textBrowser_Stu_Announcement"));
        textBrowser_Stu_Announcement->setGeometry(QRect(0, 140, 721, 311));
        label_Stu_Welcome = new QLabel(page_0_Student_Panel);
        label_Stu_Welcome->setObjectName(QString::fromUtf8("label_Stu_Welcome"));
        label_Stu_Welcome->setGeometry(QRect(0, 0, 521, 81));
        stackedWidget_StudentPanel->addWidget(page_0_Student_Panel);
        page_1_Student_View_Courses = new QWidget();
        page_1_Student_View_Courses->setObjectName(QString::fromUtf8("page_1_Student_View_Courses"));
        tableView_Student_View_Courses = new QTableView(page_1_Student_View_Courses);
        tableView_Student_View_Courses->setObjectName(QString::fromUtf8("tableView_Student_View_Courses"));
        tableView_Student_View_Courses->setGeometry(QRect(110, 50, 521, 381));
        label_My_Courses = new QLabel(page_1_Student_View_Courses);
        label_My_Courses->setObjectName(QString::fromUtf8("label_My_Courses"));
        label_My_Courses->setGeometry(QRect(300, 10, 171, 31));
        QFont font;
        font.setPointSize(18);
        font.setBold(true);
        font.setWeight(75);
        label_My_Courses->setFont(font);
        stackedWidget_StudentPanel->addWidget(page_1_Student_View_Courses);
        page_2_Student_View_Grades = new QWidget();
        page_2_Student_View_Grades->setObjectName(QString::fromUtf8("page_2_Student_View_Grades"));
        pushButton_Student_Calculate_GPA = new QPushButton(page_2_Student_View_Grades);
        pushButton_Student_Calculate_GPA->setObjectName(QString::fromUtf8("pushButton_Student_Calculate_GPA"));
        pushButton_Student_Calculate_GPA->setGeometry(QRect(70, 400, 91, 23));
        label_Student_GPA = new QLabel(page_2_Student_View_Grades);
        label_Student_GPA->setObjectName(QString::fromUtf8("label_Student_GPA"));
        label_Student_GPA->setGeometry(QRect(160, 400, 91, 21));
        tableView_Student_View_Grades = new QTableView(page_2_Student_View_Grades);
        tableView_Student_View_Grades->setObjectName(QString::fromUtf8("tableView_Student_View_Grades"));
        tableView_Student_View_Grades->setGeometry(QRect(60, 50, 641, 391));
        label_My_Grades = new QLabel(page_2_Student_View_Grades);
        label_My_Grades->setObjectName(QString::fromUtf8("label_My_Grades"));
        label_My_Grades->setGeometry(QRect(300, 10, 141, 31));
        label_My_Grades->setFont(font);
        stackedWidget_StudentPanel->addWidget(page_2_Student_View_Grades);
        tableView_Student_View_Grades->raise();
        pushButton_Student_Calculate_GPA->raise();
        label_Student_GPA->raise();
        label_My_Grades->raise();
        pushButton_Student_MainMenu = new QPushButton(page_5_StudentPanel);
        pushButton_Student_MainMenu->setObjectName(QString::fromUtf8("pushButton_Student_MainMenu"));
        pushButton_Student_MainMenu->setGeometry(QRect(610, 20, 75, 23));
        label_StudentPanel = new QLabel(page_5_StudentPanel);
        label_StudentPanel->setObjectName(QString::fromUtf8("label_StudentPanel"));
        label_StudentPanel->setGeometry(QRect(320, 0, 141, 21));
        label_Display_StudentID = new QLabel(page_5_StudentPanel);
        label_Display_StudentID->setObjectName(QString::fromUtf8("label_Display_StudentID"));
        label_Display_StudentID->setGeometry(QRect(80, 10, 81, 16));
        label_Student_ID = new QLabel(page_5_StudentPanel);
        label_Student_ID->setObjectName(QString::fromUtf8("label_Student_ID"));
        label_Student_ID->setGeometry(QRect(20, 10, 61, 16));
        label_Name = new QLabel(page_5_StudentPanel);
        label_Name->setObjectName(QString::fromUtf8("label_Name"));
        label_Name->setGeometry(QRect(170, 10, 47, 13));
        label_Display_Name = new QLabel(page_5_StudentPanel);
        label_Display_Name->setObjectName(QString::fromUtf8("label_Display_Name"));
        label_Display_Name->setGeometry(QRect(210, 10, 91, 16));
        stackedWidget_Main->addWidget(page_5_StudentPanel);

        horizontalLayout->addWidget(stackedWidget_Main);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 800, 26));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "ARIJ", nullptr));
        pushButton_Student->setText(QApplication::translate("MainWindow", "Student", nullptr));
        label_UHD->setText(QString());
        pushButton_Admin->setText(QApplication::translate("MainWindow", "Administrator", nullptr));
        label_ARIJ->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:24pt; font-weight:600; color:#00aaff;\">ARIJ - Learning Management System</span></p><p align=\"center\"><br/></p><p align=\"center\"><span style=\" font-size:12pt; font-weight:600; color:#a5a5a5;\">Please select from the following menu.</span></p></body></html>", nullptr));
        label_Copyright->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#d4d4d4;\">Copyright 2019 ARIJ - LMS</span></p></body></html>", nullptr));
        label_Admin_Login->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Administrator Login</span></p></body></html>", nullptr));
        pushButton_Admin_Return->setText(QApplication::translate("MainWindow", "Return", nullptr));
        label_Username->setText(QApplication::translate("MainWindow", "Username", nullptr));
        label_PW->setText(QApplication::translate("MainWindow", "Password", nullptr));
        pushButton_Admin_Login->setText(QApplication::translate("MainWindow", "Login", nullptr));
        label_Forgot_PW->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#0000ff;\">Forgot password?</span></p></body></html>", nullptr));
        label_Server_Status->setText(QApplication::translate("MainWindow", "[+]Status", nullptr));
        label_Student_Login->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Student Login</span></p></body></html>", nullptr));
        pushButton_Student_Return->setText(QApplication::translate("MainWindow", "Return", nullptr));
        label_Password_2->setText(QApplication::translate("MainWindow", "Password", nullptr));
        label_Username_2->setText(QApplication::translate("MainWindow", "User ID", nullptr));
        pushButton_Student_Login->setText(QApplication::translate("MainWindow", "Login", nullptr));
        label_Forgot_PW_2->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#0000ff;\">Forgot password?</span></p></body></html>", nullptr));
        label_AdminPanel->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; font-weight:600;\">Admin Panel</span></p></body></html>", nullptr));
        pushButton_Admin_Logout->setText(QApplication::translate("MainWindow", "Logout", nullptr));
        pushButton_View_Students->setText(QApplication::translate("MainWindow", "View Students", nullptr));
        pushButton_Manage_Students->setText(QApplication::translate("MainWindow", "Manage Students", nullptr));
        label_Admin_Welcome->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Welcome to the admin panel. </p><p>Here you can manage your courses &amp; manage any students registered.</p><p>Use the buttons to navigate the panel.</p></body></html>", nullptr));
        groupBox_Manage_Students->setTitle(QApplication::translate("MainWindow", "Manage Students", nullptr));
        label_M_User->setText(QApplication::translate("MainWindow", "User", nullptr));
        label_M_Pass->setText(QApplication::translate("MainWindow", "Pass", nullptr));
        label_M_UserID->setText(QApplication::translate("MainWindow", "UserID", nullptr));
        label_M_Status->setText(QApplication::translate("MainWindow", "Status", nullptr));
        pushButton_Student_Register->setText(QApplication::translate("MainWindow", "Register Student", nullptr));
        pushButton_Student_Modify->setText(QApplication::translate("MainWindow", "Modify", nullptr));
        pushButton_Student_Load->setText(QApplication::translate("MainWindow", "Load", nullptr));
        pushButton_Student_Clear->setText(QApplication::translate("MainWindow", "Clear", nullptr));
        groupBox_DeleteStudent->setTitle(QApplication::translate("MainWindow", "Delete", nullptr));
        pushButton_Student_Remove->setText(QApplication::translate("MainWindow", "Remove", nullptr));
        label_StudentID->setText(QApplication::translate("MainWindow", "Enter Student ID", nullptr));
        groupBox_M_Courses->setTitle(QApplication::translate("MainWindow", "Manage Courses", nullptr));
        label_M_Courses->setText(QApplication::translate("MainWindow", "Course Name", nullptr));
        label_M_CourseID->setText(QApplication::translate("MainWindow", "Course ID", nullptr));
        label_M_Subj->setText(QApplication::translate("MainWindow", "Course Subject", nullptr));
        label_M_Meeting->setText(QApplication::translate("MainWindow", "Meeting", nullptr));
        groupBox_Delete_Courses->setTitle(QApplication::translate("MainWindow", "Delete", nullptr));
        pushButton_Course_Remove->setText(QApplication::translate("MainWindow", "Remove", nullptr));
        label_Delete_Course->setText(QApplication::translate("MainWindow", "Enter Course Name", nullptr));
        label_Student_Name->setText(QApplication::translate("MainWindow", "Enter Student ID", nullptr));
        pushButton_Course_Register->setText(QApplication::translate("MainWindow", "Register Course", nullptr));
        pushButton_Course_Load->setText(QApplication::translate("MainWindow", "Load Course", nullptr));
        pushButton_Course_Clear->setText(QApplication::translate("MainWindow", "Clear", nullptr));
        pushButton_Course_Modify->setText(QApplication::translate("MainWindow", "Modify", nullptr));
        pushButton_Add_Student->setText(QApplication::translate("MainWindow", "Add ", nullptr));
        pushButton_Load_Student_MCourse->setText(QApplication::translate("MainWindow", "Load Student", nullptr));
        pushButton_Load_Student_Grades->setText(QApplication::translate("MainWindow", "Load Student", nullptr));
        label_test1->setText(QApplication::translate("MainWindow", "Test 1", nullptr));
        label_test2->setText(QApplication::translate("MainWindow", "Test 2", nullptr));
        label_test3->setText(QApplication::translate("MainWindow", "Test 3", nullptr));
        label_test4->setText(QApplication::translate("MainWindow", "Test 4", nullptr));
        pushButton_Load_Student_Course->setText(QApplication::translate("MainWindow", "Load Course", nullptr));
        label_Welcome_Grades->setText(QApplication::translate("MainWindow", "Welcome to the Mange Grades Panel. ", nullptr));
        label_Welcome_Instructions->setText(QApplication::translate("MainWindow", "To begin  first click on load button to find the correct student, then click on the load course to find the correct course.", nullptr));
        pushButton_Student_Add_Grade->setText(QApplication::translate("MainWindow", "Add Grade", nullptr));
        pushButton_Student_Modify_grade->setText(QApplication::translate("MainWindow", "Modify", nullptr));
        pushButton_Manage_Courses->setText(QApplication::translate("MainWindow", "Manage Course", nullptr));
        pushButton_Manage_Grades->setText(QApplication::translate("MainWindow", "Manage Grades", nullptr));
        pushButton_View_Courses->setText(QApplication::translate("MainWindow", "View Courses", nullptr));
        pushButton_Student_View_Courses->setText(QApplication::translate("MainWindow", "View My Courses", nullptr));
        pushButton_Student_View_Grades->setText(QApplication::translate("MainWindow", "View Grades", nullptr));
        pushButton_Student_Logout->setText(QApplication::translate("MainWindow", "Logout", nullptr));
        label_Stu_Announcement->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:11pt; font-weight:600;\">Announcements</span></p></body></html>", nullptr));
        label_Stu_Welcome->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Welcome to the student panel. Use the buttons to navigate the panel.</p><p>Here you can view your courses, GPA, manage courses, and view the administrator announcements</p></body></html>", nullptr));
        label_My_Courses->setText(QApplication::translate("MainWindow", "My Courses", nullptr));
        pushButton_Student_Calculate_GPA->setText(QApplication::translate("MainWindow", "Calculate GPA", nullptr));
        label_Student_GPA->setText(QString());
        label_My_Grades->setText(QApplication::translate("MainWindow", "My Grades", nullptr));
        pushButton_Student_MainMenu->setText(QApplication::translate("MainWindow", "Main Menu", nullptr));
        label_StudentPanel->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">Student Panel</span></p></body></html>", nullptr));
        label_Display_StudentID->setText(QString());
        label_Student_ID->setText(QApplication::translate("MainWindow", "Student ID:", nullptr));
        label_Name->setText(QApplication::translate("MainWindow", "Name: ", nullptr));
        label_Display_Name->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
