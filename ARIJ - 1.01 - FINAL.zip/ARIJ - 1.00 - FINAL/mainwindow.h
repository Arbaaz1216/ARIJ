#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>

namespace Ui

{ class MainWindow; }

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    void connClose()
    {
        myDB.close();
        myDB.removeDatabase(QSqlDatabase::defaultConnection);
    }
    bool connOpen()
    {
        myDB = QSqlDatabase::addDatabase("QSQLITE");
        myDB.setDatabaseName("LMSNew.db");

        if(!myDB.open())
        {
           qDebug() << "Database failed to open.";
           return false;
        }
        else
        {
            qDebug() << "DB opened.";
            return true;
        }
    }

    QSqlDatabase myDB;

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    //admin functions
    void on_pushButton_Admin_clicked();

    void on_pushButton_Admin_Return_clicked();

    void on_pushButton_Admin_Login_clicked();

    void on_pushButton_Admin_Logout_clicked();

    void on_pushButton_View_Students_clicked();

    void on_pushButton_Manage_Students_clicked();

    void on_pushButton_Student_Register_clicked();

    void on_pushButton_Student_Modify_clicked();

    void on_pushButton_Student_Remove_clicked();

    void on_pushButton_Student_Load_clicked();

    void on_comboBox_Load_Students_currentIndexChanged(const QString &arg1);

    void on_pushButton_Student_Clear_clicked();

    void on_pushButton_Manage_Courses_clicked();

    void on_pushButton_Course_Load_clicked();

    void on_pushButton_Course_Register_clicked();

    void on_pushButton_Course_Clear_clicked();

    void on_comboBox_Load_Courses_currentIndexChanged(const QString &arg1);

    void on_pushButton_Course_Remove_clicked();

    void on_pushButton_Manage_Grades_clicked();

    void on_pushButton_Load_Student_Grades_clicked();

    void on_comboBox_Load_Student_Grades_currentIndexChanged(const QString &arg1);

    void on_pushButton_Course_Modify_clicked();

    void on_pushButton_View_Courses_clicked();


    //student functions
    void on_pushButton_Student_clicked();

    void on_pushButton_Student_Return_clicked();

    void on_pushButton_Student_Login_clicked();

    void on_pushButton_Student_View_Courses_clicked();

    void on_pushButton_Student_Logout_clicked();

    void on_pushButton_Student_MainMenu_clicked();

    void on_pushButton_Student_View_Grades_clicked();

    void on_pushButton_Student_Calculate_GPA_clicked();

    void ClearAll();


    void on_pushButton_Load_Student_Course_clicked();

    void on_comboBox_Load_Student_Course_currentIndexChanged(const QString &arg1);

    void on_pushButton_Student_Add_Grade_clicked();

    void on_pushButton_Student_Modify_grade_clicked();

    void on_comboBox_Load_Student_MCourse_currentIndexChanged(const QString &arg1);

    void on_pushButton_Load_Student_MCourse_clicked();

    void on_pushButton_Add_Student_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
