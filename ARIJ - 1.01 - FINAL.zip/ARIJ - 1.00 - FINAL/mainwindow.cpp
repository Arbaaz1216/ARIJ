#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <fstream>
#include <iostream>
#include <string>
#include <cstdlib>
#include <QFile>
#include <QTextStream>

QString userSave;
QString CurrentID;
QString CurrentCourse;

using namespace std;

//Constructor
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    if(!connOpen())
    { ui->label_Server_Status->setText("Failed"); }
    else
    { ui->label_Server_Status->setText(""); }
}

//Destructor
MainWindow::~MainWindow()
{ delete ui; }

/*--------------------------NAVIGATION FUNCTIONS-------------------------------*/

/* ----------------------RETURN TO LOGIN FUNCTIONS---------------------------- */
//admin page -> login page
void MainWindow::on_pushButton_Admin_Return_clicked()
{ ui->stackedWidget_Main->setCurrentIndex(0); }

//student page -> login page
void MainWindow::on_pushButton_Student_Return_clicked()
{ ui->stackedWidget_Main->setCurrentIndex(0); }

//admin panel -> login page
void MainWindow::on_pushButton_Admin_Logout_clicked()
{ ui->stackedWidget_Main->setCurrentIndex(0); }

//student panel -> login page
void MainWindow::on_pushButton_Student_Logout_clicked()
{ ui->stackedWidget_Main->setCurrentIndex(0);
        ClearAll(); }
/* ----------------------PANEL NAVIGATION FUNCTIONS---------------------------- */

//admin page -> admin panel
void MainWindow::on_pushButton_Admin_clicked()
{ ui->stackedWidget_Main->setCurrentIndex(1); }

//student page -> student panel
void MainWindow::on_pushButton_Student_clicked()
{ ui->stackedWidget_Main->setCurrentIndex(2); }

//student view courses/student view grades - > main menu
void MainWindow::on_pushButton_Student_MainMenu_clicked()
{ ui->stackedWidget_StudentPanel->setCurrentIndex(0);
    ui->label_Student_GPA->clear(); }

//admin panel -> manage students panel
void MainWindow::on_pushButton_Manage_Students_clicked()
{ ui->stackedWidget_AdminPanel->setCurrentIndex(2); }

//admin panel -> manage courses panel
void MainWindow::on_pushButton_Manage_Courses_clicked()
{ ui->stackedWidget_AdminPanel->setCurrentIndex(3); }

/* ---------------------------------------------------------------------------- */

void MainWindow::on_pushButton_Admin_Login_clicked()
{
    //create Qstring for username and pw to save text from lines
    QString username_admin, password_admin;
    username_admin = ui->lineEdit_Admin_Login->text();
    password_admin = ui->lineEdit_Admin_Pass->text();

    //if connection doesnt open display error
    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

   //connection open
    connOpen();

    //create query
    QSqlQuery qry;
    qry.prepare("select * from admin where user = '"+username_admin+"' and pass = '"+password_admin+"' ");

   if (qry.exec())
        {
            int count = 0;
            while(qry.next())
            { count++; }

            if(count ==1)
            { connClose();
              QMessageBox::information(this, "Login File", "You have logged in as admin.");
              ui->stackedWidget_Main->setCurrentIndex(3);
            }
            else if(count >1)
            { qDebug() << "Duplicate"; }
            else  if(count < 1)
            { QMessageBox::warning(this, "Login", "Incorrect username and password."); }
        }
   //if wrong username and pw entered clear lines
    ui->lineEdit_Admin_Login->clear();
    ui->lineEdit_Admin_Pass->clear();
}


void MainWindow::on_pushButton_Student_Login_clicked()
{
    //create Qstring for username and pw to save text from lines
    QString username_student, password_student;
    username_student = ui->lineEdit_Student_Login->text();
    password_student = ui->lineEdit_Student_Pass->text();

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    //connection open
    connOpen();

    //create query
    QSqlQuery qry;
    qry.prepare("select * from studinfo where stuid = '"+username_student+"' and password = '"+password_student+"' ");

if (qry.exec())
    {
        int count = 0;
        while(qry.next())
        { count++; }

        if(count ==1)
        {
            QMessageBox::information(this, "Login File", "You have logged in.");
            connClose();
            ui->stackedWidget_Main->setCurrentIndex(4);
            QFile fileWelcome("data\\StudentWelcome.txt");

                if(!fileWelcome.open(QIODevice::ReadOnly))
                { QMessageBox::information(0, "info", fileWelcome.errorString());}

            QTextStream in(&fileWelcome);
            ui->textBrowser_Stu_Announcement->setText(in.readAll());
            ui->label_Display_StudentID->setText(username_student);

        }
       else if(count >1)
        { qDebug() << "Duplicate"; }
      else  if(count < 1)
        { QMessageBox::warning(this, "Login", "Incorrect username and password."); }
    }

    //save username to userSave
    userSave = username_student;

    //if wrong username and pw entered clear lines
    ui->lineEdit_Student_Login->clear();
    ui->lineEdit_Student_Pass->clear();
}

void MainWindow::on_pushButton_Student_View_Courses_clicked()
{
   //student panel -> student view courses panel
    ui->stackedWidget_StudentPanel->setCurrentIndex(1);

    //initialize pointer to model
    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();

    //create query
    QSqlQuery* qry = new QSqlQuery(this->myDB);

    //access database from userSave name [data bases are named by userID]
    qry->prepare("select subject as Subject, courseid as 'Course ID', name as Name, hours as Hours, status as Status from '"+userSave+"' ");
    qry->exec();

    model->setQuery(*qry);

    //display current student courses
    ui->tableView_Student_View_Courses->setModel(model);
    connClose();
    qDebug() << (model->rowCount());
}

void MainWindow::on_pushButton_Student_View_Grades_clicked()
{
    //student panel -> student view grades panel
    ui->stackedWidget_StudentPanel->setCurrentIndex(2);

    //intialize pointer model
    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();

    //create query
    QSqlQuery* qry = new QSqlQuery(this->myDB);

    //access database from userSave [data bases are named by userID]
    qry->prepare("select fullcourse as Courses, average as 'Grade Average', t1 as 'Test 1', t2 as 'Test 2',t3 as 'Test 3', t4 as 'Test 4' from '"+userSave+"'");
    qry->exec();

    model->setQuery(*qry);

    //
    ui->tableView_Student_View_Grades->setModel(model);
    connClose();
    qDebug() << (model->rowCount());

}

void MainWindow::on_pushButton_Student_Calculate_GPA_clicked()
{
    QString GPA;
    if(!connOpen())
    {
        qDebug() << "Database failed to open.";
        return;
    }

    connOpen();

    QSqlQuery qry;
   // qry.prepare("select gpa from studinfo where stuid='"+userPt+"'");
    qry.prepare("select t1 as 'Test 1', t2 as 'Test 2',t3 as 'Test 3', t4 as 'Test 4' from '"+userSave+"'");

    QString g1;
    QString g2;
    string gr[4];

    int test1,test2,test3,test4;

    //t1 = qry.(0)

    int n[4];
if (qry.exec())
    {
        while(qry.next())
        {
            g1 = qry.value(0).toString();
           // ui->label_GPA->setText(qry.value(0).toString());
          /*  g[0] = qry.value(0).toString();
            g[1] = qry.value(1).toString();
            g[2] = qry.value(2).toString();
            g[3] = qry.value(3).toString();

            gr[0] = g[0].toStdString();
             gr[1] = g[1].toStdString();
              gr[2] = g[2].toStdString();
               gr[3] = g[3].toStdString();
*/
               /* if(gr[0] == "A")
                {
                     n[0] = 3;
                 }
                else
                {
                    n[0] = 10;
                }*/
           // int total= n[0] + n[1] + n[2] + n[3];

           // QString x = QString::number(total);
            // QString x = QString::number(n[2]);
         //   ui->label_GPA->setText(qry.value(1).toString());
            ui->label_Student_GPA->setText("NULL");

        }
        connClose();
    }
    else
    {
    QMessageBox::critical(this, tr("Error"), qry.lastError().text());
    }
}

void MainWindow::ClearAll()
{ ui->label_Student_GPA->clear(); }

//admin panel -> admin view students panel
void MainWindow::on_pushButton_View_Students_clicked()
{
    ui->stackedWidget_AdminPanel->setCurrentIndex(1);
    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);

    //access database from stuid and display student, pw, status, and gpa
    qry->prepare("select name as Student, stuid as ID, password as Password, status as Standing, gpa as GPA from studinfo");
    qry->exec();

    model->setQuery(*qry);
    //display student information on table
    ui->tableView_Display_Students->setModel(model);
    connClose();
    qDebug() << (model->rowCount());
}

//register student button
void MainWindow::on_pushButton_Student_Register_clicked()
{
    //create Qstring for user, pw, id, status to save the text lines to register
    QString user_reg, pass_reg, uid_reg, status_reg;
    user_reg = ui->lineEdit_Stu_User->text();
    pass_reg = ui->lineEdit_Stu_Password->text();
    uid_reg = ui->lineEdit_Stu_UserID->text();
    status_reg = ui->lineEdit_Stu_Status->text();

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();

    //create query
    QSqlQuery qry;
    //access database from studinfo and input new values saved from the text lines
    qry.prepare("insert into studinfo (name, password, stuid, status) values('"+user_reg+"','"+pass_reg+"','"+uid_reg+"','"+status_reg+"')");

    if (qry.exec())
    {
        QMessageBox::information(this, tr("Save"), tr("Information inserted"));
       ui->lineEdit_Stu_User->clear();
       ui->lineEdit_Stu_Password->clear();
       ui->lineEdit_Stu_UserID->clear();
       ui->lineEdit_Stu_Status->clear();
        connClose();
    }
    //if not saved will display error
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }

    connOpen();
    //create table for new student
    QString qry_new = "CREATE TABLE '"+uid_reg+"' ("
                       "subject TEXT,"
                       "courseid INTEGER, "
                       "name varchar(20), "
                       "hours INTEGER,"
                       "status TEXT, "
                       "average INTEGER, "
                       "t1 INTEGER, "
                        "t2 INTEGER, "
                        "t3 INTEGER, "
                        "t4 INTEGER, "
                        "fullcourse TEXT);";

    QSqlQuery qry1;
    if (!qry1.exec(qry_new))
    { qDebug()<<"Error creating the table";}
    else
    {qDebug()<<"End"; }
    connClose();
}

//modify already saved student information button
void MainWindow::on_pushButton_Student_Modify_clicked()
{
    //create Qstring for user, pw, id, status to save the text lines to modify
    QString user_mod, pass_mod, uid_mod, status_mod;
    user_mod = ui->lineEdit_Stu_User->text();
    pass_mod = ui->lineEdit_Stu_Password->text();
    uid_mod = ui->lineEdit_Stu_UserID->text();
    status_mod = ui->lineEdit_Stu_Status->text();
    if(!connOpen())

    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    QSqlQuery qry;
    //access database from studinfo and update new values saved from the text lines
    qry.prepare("update studinfo set name='"+user_mod+"', password='"+pass_mod+"', stuid='"+uid_mod+"', status='"+status_mod+"' where name='"+user_mod+"'");

    if (qry.exec())
    {
        QMessageBox::information(this, tr("Updated"), tr("Information updated"));
       ui->lineEdit_Stu_User->clear();
       ui->lineEdit_Stu_Password->clear();
       ui->lineEdit_Stu_UserID->clear();
       ui->lineEdit_Stu_Status->clear();
        connClose();
    }
    //if not saved will display error
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
}

void MainWindow::on_pushButton_Student_Remove_clicked()
{
    //create Qstring for user, pw, id, status to remove
    QString user_del, pass_del, uid_del, status_del;

    //enter in the name of the student id to delete
    uid_del = ui->lineEdit_Student_Remove->text();

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    QSqlQuery qry;
    //access database from studinfo and delete everything from studentid
    qry.prepare("delete from studinfo where stuid='"+uid_del+"'");

    if (qry.exec())
    {
        QMessageBox::information(this, tr("Remove"), tr("Information removed"));
       ui->lineEdit_Stu_User->clear();
       ui->lineEdit_Stu_Password->clear();
       ui->lineEdit_Stu_UserID->clear();
       ui->lineEdit_Stu_Status->clear();
       ui->lineEdit_Student_Remove->clear();
        connClose();
    }
    //if not saved will display error
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }

    connOpen();
    //delete table from database
    QString qry_new = "DROP TABLE '"+uid_del+"' ";
    QSqlQuery qry1;
    connClose();

    if (!qry1.exec(qry_new))
    { qDebug()<<"Error deleting the table";}
    else
    {qDebug()<<"End"; }


}

//load all names of current students
void MainWindow::on_pushButton_Student_Load_clicked()
{
    QSqlQueryModel * model2 = new QSqlQueryModel();

    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    //access database from studinfo and link to all names
    qry->prepare("select name from studinfo");
    qry->exec();

    model2->setQuery(*qry);
    //display all names to select
    ui->comboBox_Load_Students->setModel(model2);
    connClose();
    qDebug() << (model2->rowCount());
}


void MainWindow::on_comboBox_Load_Students_currentIndexChanged(const QString &arg1)
{
    QString name =ui->comboBox_Load_Students->currentText();

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    //create query
    QSqlQuery qry;
    //access database information from studinfo for the name chosen
    qry.prepare("select * from studinfo where name='"+name+"'");

    if (qry.exec())
    {
        while(qry.next())
        {
            ui->lineEdit_Stu_User->setText(qry.value(0).toString());
            ui->lineEdit_Stu_Password->setText(qry.value(2).toString());
            ui->lineEdit_Stu_UserID->setText(qry.value(1).toString());
            ui->lineEdit_Stu_Status->setText(qry.value(3).toString());
        }
        connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
}

//clear button for student manage panel
void MainWindow::on_pushButton_Student_Clear_clicked()
{
    //clear every lineEdit for username, pw, id, status
    ui->lineEdit_Stu_User->clear();
    ui->lineEdit_Stu_Password->clear();
    ui->lineEdit_Stu_UserID->clear();
    ui->lineEdit_Stu_Status->clear();
}

//load course information
void MainWindow::on_pushButton_Course_Load_clicked()
{
    QSqlQueryModel * model3 = new QSqlQueryModel();

    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);
    //access database from course info and load names
    qry->prepare("select name from courseinfo");
    qry->exec();

    model3->setQuery(*qry);
    //display all names for courses
    ui->comboBox_Load_Courses->setModel(model3);
    connClose();
    qDebug() << (model3->rowCount());
}

//register for courses button
void MainWindow::on_pushButton_Course_Register_clicked()
{
    //create Qstring for name, id, subject, and status
    QString course_name, course_id, course_subj, course_stat, course_hour;
    course_name = ui->lineEdit_courseN->text();
    course_id = ui->lineEdit_courseID->text();
    course_subj = ui->lineEdit_courseSubj->text();
    course_stat = ui->lineEdit_courseMeet->text();
    course_hour = course_id[1];

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    //create query
    QSqlQuery qry;
    //access database from courseinfo and insert new values from lineEdits [name, id, subject, and status]
    qry.prepare("insert into courseinfo (name, courseid, subject, Hours, status) values('"+course_name+"','"+course_id+"','"+course_subj+"','"+course_hour+"','"+course_stat+"')");

    if (qry.exec())
    {
       QMessageBox::information(this, tr("Save"), tr("Information inserted"));
       ui->lineEdit_courseN->clear();
       ui->lineEdit_courseID->clear();
       ui->lineEdit_courseSubj->clear();
       ui->lineEdit_courseMeet->clear();
       connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
}

//clear all selected lineEdits
void MainWindow::on_pushButton_Course_Clear_clicked()
{
    {
        //clear all lineEdits for course name, id, meeting, subject
        ui->lineEdit_courseN->clear();
        ui->lineEdit_courseID->clear();
        ui->lineEdit_courseMeet->clear();
        ui->lineEdit_courseSubj->clear();
    }
}


void MainWindow::on_comboBox_Load_Courses_currentIndexChanged(const QString &arg1)
{
    //load courses and display all current course names
    QString name =ui->comboBox_Load_Courses->currentText();

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    //create query
    QSqlQuery qry;
    //access database from courseinfo for selected name
    qry.prepare("select * from courseinfo where name='"+name+"'");

    if (qry.exec())
    {
        while(qry.next())
        {
            //load selected name with course information
            ui->lineEdit_courseN->setText(qry.value(2).toString());
            ui->lineEdit_courseID->setText(qry.value(1).toString());
            ui->lineEdit_courseSubj->setText(qry.value(0).toString());
            ui->lineEdit_courseMeet->setText(qry.value(4).toString());
            CurrentCourse = name;
        }
        connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
}

void MainWindow::on_pushButton_Course_Remove_clicked()
{
    //create Qstring for course name, id, subject, and status
    QString courseN_del, courseID_del, courseSubj_del, courseStatus_del;
    courseN_del = ui->lineEdit_Course_Remove->text();

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    QSqlQuery qry;
    //access database from courseinfo for selected course name
    qry.prepare("delete from courseinfo where name='"+courseN_del+"'");

    if (qry.exec())
    {
       QMessageBox::information(this, tr("Remove"), tr("Information removed"));
       //remove course information from lineEdits
       ui->lineEdit_courseN->clear();
       ui->lineEdit_courseID->clear();
       ui->lineEdit_courseSubj->clear();
       ui->lineEdit_courseMeet->clear();
       ui->lineEdit_Course_Remove->clear();
        connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
}

void MainWindow::on_pushButton_Manage_Grades_clicked()
{
    //admin panel -> admin manage grades panel
    ui->stackedWidget_AdminPanel->setCurrentIndex(4);

    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();

    QSqlQuery* qry = new QSqlQuery(this->myDB);

    //access database from userSave [student ID #] for name, avg, t1, t2, t3, t4 information
    qry->prepare("select fullcourse as Courses, average as 'Grades Average', t1 as 'Test 1', t2 as 'Test 2',t3 as 'Test 3', t4 as 'Test 4' from '"+userSave+"'");
    qry->exec();

    model->setQuery(*qry);
    //display current student grades
    ui->tableView_Display_Grades->setModel(model);
    connClose();
    qDebug() << (model->rowCount());
}

void MainWindow::on_pushButton_Load_Student_Grades_clicked()
{
    QSqlQueryModel * model4 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);

    //access database from stuid for student id information
    qry->prepare("select stuid from studinfo");
    qry->exec();

    model4->setQuery(*qry);
    //load all student grades
    ui->comboBox_Load_Student_Grades->setModel(model4);
    connClose();
    qDebug() << (model4->rowCount());
}

void MainWindow::on_comboBox_Load_Student_Grades_currentIndexChanged(const QString &arg1)
{
    //create Qstring ID from the loaded student grades ID
    QString studentID =ui->comboBox_Load_Student_Grades->currentText();

    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();

    QSqlQuery* qry1 = new QSqlQuery(this->myDB);

    //access database from student ID for tests t1,t2,t3,t4
    qry1->prepare("select fullcourse as Courses, average as 'Grades Average', t1 as 'Test 1', t2 as 'Test 2',t3 as 'Test 3', t4 as 'Test 4' from '"+studentID+"'");

    qry1->exec();
    model->setQuery(*qry1);
    //display all grades
    ui->tableView_Display_Grades->setModel(model);
    connClose();

    CurrentID = studentID;
}

void MainWindow::on_pushButton_Course_Modify_clicked()
{
    //create QString for course name, subj, id, status
    QString courseN_mod, courseSubj_mod, courseID_mod, courseStatus_mod;

    //modify the course information
    courseN_mod = ui->lineEdit_courseN->text();
    courseSubj_mod = ui->lineEdit_courseSubj->text();
    courseID_mod = ui->lineEdit_courseID->text();
    courseStatus_mod = ui->lineEdit_courseMeet->text();
    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    QSqlQuery qry;

    //access data base from courseinfo to modify course name, subj, id, status with the saved lines
    qry.prepare("update courseinfo set name='"+courseN_mod+"', subject='"+courseSubj_mod+"', courseid='"+courseID_mod+"', status='"+courseStatus_mod+"' where name='"+courseN_mod+"'");

    if (qry.exec())
    {
        QMessageBox::information(this, tr("Updated"), tr("Information updated"));
        //clear all lines after modify has been completed
       ui->lineEdit_courseN->clear();
       ui->lineEdit_courseSubj->clear();
       ui->lineEdit_courseID->clear();
       ui->lineEdit_courseMeet->clear();
        connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
}

void MainWindow::on_pushButton_View_Courses_clicked()
{
    ui->stackedWidget_AdminPanel->setCurrentIndex(5);
    QSqlQueryModel * model = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);

    //access database from stuid and display subj, courseid, name, hours, and status
    qry->prepare("select subject as Subject, courseid as 'Course ID', name as Name, Hours, status as Status from courseinfo");
    qry->exec();

    model->setQuery(*qry);

    //display student information on table
    ui->tableView_View_Courses->setModel(model);
    ui->tableView_View_Courses->setColumnWidth(0,70);
    ui->tableView_View_Courses->setColumnWidth(1,80);
    ui->tableView_View_Courses->setColumnWidth(2,170);
    ui->tableView_View_Courses->setColumnWidth(3,70);
    ui->tableView_View_Courses->setColumnWidth(4,90);
    connClose();
    qDebug() << (model->rowCount());
}

void MainWindow::on_pushButton_Load_Student_Course_clicked()
{
    QSqlQueryModel * model4 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);

    //access database from stuid for student id information
    qry->prepare("select fullcourse from '"+CurrentID+"' ");
    qry->exec();

    model4->setQuery(*qry);
    //load all student grades
    ui->comboBox_Load_Student_Course->setModel(model4);
    connClose();
    qDebug() << (model4->rowCount());
}



void MainWindow::on_comboBox_Load_Student_Course_currentIndexChanged(const QString &arg1)
{
    //create Qstring ID from the loaded student grades ID
    QString coursename =ui->comboBox_Load_Student_Course->currentText();

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    QSqlQuery qry;
    //access database from studentID for test scores t1,t2,t3,t4
    qry.prepare("select * from '"+CurrentID+"' where fullcourse='"+coursename+"'");

    if (qry.exec())
    {
        while(qry.next())
        {
            //allow edits to student test information
            ui->lineEdit_test1->setText(qry.value(6).toString());
            ui->lineEdit_test2->setText(qry.value(7).toString());
            ui->lineEdit_test3->setText(qry.value(8).toString());
            ui->lineEdit_test4->setText(qry.value(9).toString());
            CurrentCourse = coursename;
        }
        connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
}

void MainWindow::on_pushButton_Student_Add_Grade_clicked()
{
    //create Qstring for test1, test2, test3, test4
    QString t1, t2, t3, t4;
    t1 = ui->lineEdit_test1->text();
    t2 = ui->lineEdit_test2->text();
    t3 = ui->lineEdit_test3->text();
    t4 = ui->lineEdit_test4->text();

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    //create query
    QSqlQuery qry;
    //access database from CurrentID and insert new values from lineEdits [test1, test2, test3, test4]
    qry.prepare("insert into '"+CurrentID+"' (t1, t2, t3, t4) values('"+t1+"','"+t2+"','"+t3+"','"+t4+"')");

    if (qry.exec())
    {
       QMessageBox::information(this, tr("Save"), tr("Information inserted"));
       ui->lineEdit_test1->clear();
       ui->lineEdit_test2->clear();
       ui->lineEdit_test3->clear();
       ui->lineEdit_test4->clear();
       connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
    connClose();
}

void MainWindow::on_pushButton_Student_Modify_grade_clicked()
{
    //create QString for test1, test2, test3, test4
    QString test1_mod, test2_mod, test3_mod, test4_mod;

    //modify the course information
    test1_mod = ui->lineEdit_test1->text();
    test2_mod = ui->lineEdit_test2->text();
    test3_mod = ui->lineEdit_test3->text();
    test4_mod = ui->lineEdit_test4->text();
    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    QSqlQuery qry;

    //access data base from courseinfo to modify test1, test2, test3, test4 with the saved lines
    qry.prepare("update '"+CurrentID+"' set t1='"+test1_mod+"', t2='"+test2_mod+"', t3='"+test3_mod+"', t4='"+test4_mod+"' where t1='"+test1_mod+"'");

    if (qry.exec())
    {
        QMessageBox::information(this, tr("Updated"), tr("Information updated"));
        //clear all lines after modify has been completed
       ui->lineEdit_test1->clear();
       ui->lineEdit_test2->clear();
       ui->lineEdit_test3->clear();
       ui->lineEdit_test4->clear();
        connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
}

void MainWindow::on_pushButton_Load_Student_MCourse_clicked()
{
    QSqlQueryModel * model4 = new QSqlQueryModel();
    connOpen();
    QSqlQuery* qry = new QSqlQuery(this->myDB);

    //access database from stuid for student name
    qry->prepare("select name from studinfo");
    qry->exec();

    model4->setQuery(*qry);
    //load all student grades
    ui->comboBox_Load_Student_MCourse->setModel(model4);
    connClose();
    qDebug() << (model4->rowCount());
}

void MainWindow::on_comboBox_Load_Student_MCourse_currentIndexChanged(const QString &arg1)
{
    //load names and display all student names
    QString name =ui->comboBox_Load_Student_MCourse->currentText();
    QString stuid;

    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

    connOpen();
    //create query
    QSqlQuery qry;
    //access database from studinfo and retrieve name
    qry.prepare("select * from studinfo where name='"+name+"'");

    if (qry.exec())
    {
        while(qry.next())
        {
            //load selected student ID
            ui->lineEdit_Student_MCourse->setText(qry.value(1).toString());
            stuid = ui->lineEdit_Student_MCourse->text();
            CurrentID = stuid;
        }
        connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }
}

void MainWindow::on_pushButton_Add_Student_clicked()
{
    //create Qstring for name, id, subject, and status
    QString course_name, course_id, course_subj, course_stat, course_hours, fullcourse;

    course_subj = ui->lineEdit_courseSubj->text();
    course_id = ui->lineEdit_courseID->text();
    course_name = ui->lineEdit_courseN->text();
    course_stat = ui->lineEdit_courseMeet->text();
    course_hours = course_id[1];
    fullcourse = course_subj + " " + course_id;


    if(!connOpen())
    { qDebug() << "Database failed to open.";
        return; }

      //qry.prepare("insert into '"+CurrentID+"' (t1, t2, t3, t4) values('"+t1+"','"+t2+"','"+t3+"','"+t4+"')");

    connOpen();
    //create query
    QSqlQuery qry;
    //access database from courseinfo and insert new values from lineEdits [subject, courseid, name, hours, status]
    qry.prepare("insert into '"+CurrentID+"'(subject, courseid, name, hours, status, fullcourse) values('"+course_subj+"', '"+course_id+"', '"+course_name+"','"+course_hours+"', '"+course_stat+"', '"+fullcourse+"')");

    if (qry.exec())
    {
       QMessageBox::information(this, tr("Save"), tr("Information inserted"));
       ui->lineEdit_courseSubj->clear();
       ui->lineEdit_courseID->clear();
       ui->lineEdit_courseN->clear();
       ui->lineEdit_courseMeet->clear();
       connClose();
    }
    else
    { QMessageBox::critical(this, tr("Error"), qry.lastError().text()); }

}
