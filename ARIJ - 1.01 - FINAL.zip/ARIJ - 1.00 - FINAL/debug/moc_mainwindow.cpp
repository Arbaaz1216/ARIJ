/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[42];
    char stringdata0[1503];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 27), // "on_pushButton_Admin_clicked"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 34), // "on_pushButton_Admin_Return_cl..."
QT_MOC_LITERAL(4, 75, 33), // "on_pushButton_Admin_Login_cli..."
QT_MOC_LITERAL(5, 109, 34), // "on_pushButton_Admin_Logout_cl..."
QT_MOC_LITERAL(6, 144, 35), // "on_pushButton_View_Students_c..."
QT_MOC_LITERAL(7, 180, 37), // "on_pushButton_Manage_Students..."
QT_MOC_LITERAL(8, 218, 38), // "on_pushButton_Student_Registe..."
QT_MOC_LITERAL(9, 257, 36), // "on_pushButton_Student_Modify_..."
QT_MOC_LITERAL(10, 294, 36), // "on_pushButton_Student_Remove_..."
QT_MOC_LITERAL(11, 331, 34), // "on_pushButton_Student_Load_cl..."
QT_MOC_LITERAL(12, 366, 45), // "on_comboBox_Load_Students_cur..."
QT_MOC_LITERAL(13, 412, 4), // "arg1"
QT_MOC_LITERAL(14, 417, 35), // "on_pushButton_Student_Clear_c..."
QT_MOC_LITERAL(15, 453, 36), // "on_pushButton_Manage_Courses_..."
QT_MOC_LITERAL(16, 490, 33), // "on_pushButton_Course_Load_cli..."
QT_MOC_LITERAL(17, 524, 37), // "on_pushButton_Course_Register..."
QT_MOC_LITERAL(18, 562, 34), // "on_pushButton_Course_Clear_cl..."
QT_MOC_LITERAL(19, 597, 44), // "on_comboBox_Load_Courses_curr..."
QT_MOC_LITERAL(20, 642, 35), // "on_pushButton_Course_Remove_c..."
QT_MOC_LITERAL(21, 678, 35), // "on_pushButton_Manage_Grades_c..."
QT_MOC_LITERAL(22, 714, 41), // "on_pushButton_Load_Student_Gr..."
QT_MOC_LITERAL(23, 756, 51), // "on_comboBox_Load_Student_Grad..."
QT_MOC_LITERAL(24, 808, 35), // "on_pushButton_Course_Modify_c..."
QT_MOC_LITERAL(25, 844, 34), // "on_pushButton_View_Courses_cl..."
QT_MOC_LITERAL(26, 879, 29), // "on_pushButton_Student_clicked"
QT_MOC_LITERAL(27, 909, 36), // "on_pushButton_Student_Return_..."
QT_MOC_LITERAL(28, 946, 35), // "on_pushButton_Student_Login_c..."
QT_MOC_LITERAL(29, 982, 42), // "on_pushButton_Student_View_Co..."
QT_MOC_LITERAL(30, 1025, 36), // "on_pushButton_Student_Logout_..."
QT_MOC_LITERAL(31, 1062, 38), // "on_pushButton_Student_MainMen..."
QT_MOC_LITERAL(32, 1101, 41), // "on_pushButton_Student_View_Gr..."
QT_MOC_LITERAL(33, 1143, 43), // "on_pushButton_Student_Calcula..."
QT_MOC_LITERAL(34, 1187, 8), // "ClearAll"
QT_MOC_LITERAL(35, 1196, 41), // "on_pushButton_Load_Student_Co..."
QT_MOC_LITERAL(36, 1238, 51), // "on_comboBox_Load_Student_Cour..."
QT_MOC_LITERAL(37, 1290, 39), // "on_pushButton_Student_Add_Gra..."
QT_MOC_LITERAL(38, 1330, 42), // "on_pushButton_Student_Modify_..."
QT_MOC_LITERAL(39, 1373, 52), // "on_comboBox_Load_Student_MCou..."
QT_MOC_LITERAL(40, 1426, 42), // "on_pushButton_Load_Student_MC..."
QT_MOC_LITERAL(41, 1469, 33) // "on_pushButton_Add_Student_cli..."

    },
    "MainWindow\0on_pushButton_Admin_clicked\0"
    "\0on_pushButton_Admin_Return_clicked\0"
    "on_pushButton_Admin_Login_clicked\0"
    "on_pushButton_Admin_Logout_clicked\0"
    "on_pushButton_View_Students_clicked\0"
    "on_pushButton_Manage_Students_clicked\0"
    "on_pushButton_Student_Register_clicked\0"
    "on_pushButton_Student_Modify_clicked\0"
    "on_pushButton_Student_Remove_clicked\0"
    "on_pushButton_Student_Load_clicked\0"
    "on_comboBox_Load_Students_currentIndexChanged\0"
    "arg1\0on_pushButton_Student_Clear_clicked\0"
    "on_pushButton_Manage_Courses_clicked\0"
    "on_pushButton_Course_Load_clicked\0"
    "on_pushButton_Course_Register_clicked\0"
    "on_pushButton_Course_Clear_clicked\0"
    "on_comboBox_Load_Courses_currentIndexChanged\0"
    "on_pushButton_Course_Remove_clicked\0"
    "on_pushButton_Manage_Grades_clicked\0"
    "on_pushButton_Load_Student_Grades_clicked\0"
    "on_comboBox_Load_Student_Grades_currentIndexChanged\0"
    "on_pushButton_Course_Modify_clicked\0"
    "on_pushButton_View_Courses_clicked\0"
    "on_pushButton_Student_clicked\0"
    "on_pushButton_Student_Return_clicked\0"
    "on_pushButton_Student_Login_clicked\0"
    "on_pushButton_Student_View_Courses_clicked\0"
    "on_pushButton_Student_Logout_clicked\0"
    "on_pushButton_Student_MainMenu_clicked\0"
    "on_pushButton_Student_View_Grades_clicked\0"
    "on_pushButton_Student_Calculate_GPA_clicked\0"
    "ClearAll\0on_pushButton_Load_Student_Course_clicked\0"
    "on_comboBox_Load_Student_Course_currentIndexChanged\0"
    "on_pushButton_Student_Add_Grade_clicked\0"
    "on_pushButton_Student_Modify_grade_clicked\0"
    "on_comboBox_Load_Student_MCourse_currentIndexChanged\0"
    "on_pushButton_Load_Student_MCourse_clicked\0"
    "on_pushButton_Add_Student_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      39,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  209,    2, 0x08 /* Private */,
       3,    0,  210,    2, 0x08 /* Private */,
       4,    0,  211,    2, 0x08 /* Private */,
       5,    0,  212,    2, 0x08 /* Private */,
       6,    0,  213,    2, 0x08 /* Private */,
       7,    0,  214,    2, 0x08 /* Private */,
       8,    0,  215,    2, 0x08 /* Private */,
       9,    0,  216,    2, 0x08 /* Private */,
      10,    0,  217,    2, 0x08 /* Private */,
      11,    0,  218,    2, 0x08 /* Private */,
      12,    1,  219,    2, 0x08 /* Private */,
      14,    0,  222,    2, 0x08 /* Private */,
      15,    0,  223,    2, 0x08 /* Private */,
      16,    0,  224,    2, 0x08 /* Private */,
      17,    0,  225,    2, 0x08 /* Private */,
      18,    0,  226,    2, 0x08 /* Private */,
      19,    1,  227,    2, 0x08 /* Private */,
      20,    0,  230,    2, 0x08 /* Private */,
      21,    0,  231,    2, 0x08 /* Private */,
      22,    0,  232,    2, 0x08 /* Private */,
      23,    1,  233,    2, 0x08 /* Private */,
      24,    0,  236,    2, 0x08 /* Private */,
      25,    0,  237,    2, 0x08 /* Private */,
      26,    0,  238,    2, 0x08 /* Private */,
      27,    0,  239,    2, 0x08 /* Private */,
      28,    0,  240,    2, 0x08 /* Private */,
      29,    0,  241,    2, 0x08 /* Private */,
      30,    0,  242,    2, 0x08 /* Private */,
      31,    0,  243,    2, 0x08 /* Private */,
      32,    0,  244,    2, 0x08 /* Private */,
      33,    0,  245,    2, 0x08 /* Private */,
      34,    0,  246,    2, 0x08 /* Private */,
      35,    0,  247,    2, 0x08 /* Private */,
      36,    1,  248,    2, 0x08 /* Private */,
      37,    0,  251,    2, 0x08 /* Private */,
      38,    0,  252,    2, 0x08 /* Private */,
      39,    1,  253,    2, 0x08 /* Private */,
      40,    0,  256,    2, 0x08 /* Private */,
      41,    0,  257,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_Admin_clicked(); break;
        case 1: _t->on_pushButton_Admin_Return_clicked(); break;
        case 2: _t->on_pushButton_Admin_Login_clicked(); break;
        case 3: _t->on_pushButton_Admin_Logout_clicked(); break;
        case 4: _t->on_pushButton_View_Students_clicked(); break;
        case 5: _t->on_pushButton_Manage_Students_clicked(); break;
        case 6: _t->on_pushButton_Student_Register_clicked(); break;
        case 7: _t->on_pushButton_Student_Modify_clicked(); break;
        case 8: _t->on_pushButton_Student_Remove_clicked(); break;
        case 9: _t->on_pushButton_Student_Load_clicked(); break;
        case 10: _t->on_comboBox_Load_Students_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->on_pushButton_Student_Clear_clicked(); break;
        case 12: _t->on_pushButton_Manage_Courses_clicked(); break;
        case 13: _t->on_pushButton_Course_Load_clicked(); break;
        case 14: _t->on_pushButton_Course_Register_clicked(); break;
        case 15: _t->on_pushButton_Course_Clear_clicked(); break;
        case 16: _t->on_comboBox_Load_Courses_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: _t->on_pushButton_Course_Remove_clicked(); break;
        case 18: _t->on_pushButton_Manage_Grades_clicked(); break;
        case 19: _t->on_pushButton_Load_Student_Grades_clicked(); break;
        case 20: _t->on_comboBox_Load_Student_Grades_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 21: _t->on_pushButton_Course_Modify_clicked(); break;
        case 22: _t->on_pushButton_View_Courses_clicked(); break;
        case 23: _t->on_pushButton_Student_clicked(); break;
        case 24: _t->on_pushButton_Student_Return_clicked(); break;
        case 25: _t->on_pushButton_Student_Login_clicked(); break;
        case 26: _t->on_pushButton_Student_View_Courses_clicked(); break;
        case 27: _t->on_pushButton_Student_Logout_clicked(); break;
        case 28: _t->on_pushButton_Student_MainMenu_clicked(); break;
        case 29: _t->on_pushButton_Student_View_Grades_clicked(); break;
        case 30: _t->on_pushButton_Student_Calculate_GPA_clicked(); break;
        case 31: _t->ClearAll(); break;
        case 32: _t->on_pushButton_Load_Student_Course_clicked(); break;
        case 33: _t->on_comboBox_Load_Student_Course_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 34: _t->on_pushButton_Student_Add_Grade_clicked(); break;
        case 35: _t->on_pushButton_Student_Modify_grade_clicked(); break;
        case 36: _t->on_comboBox_Load_Student_MCourse_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 37: _t->on_pushButton_Load_Student_MCourse_clicked(); break;
        case 38: _t->on_pushButton_Add_Student_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 39)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 39;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 39)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 39;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
