This executable file is in early stages.

It currently allows the user to input login information to access the admin panel.
'users' contains the user's information.

name.txt 	-> 	name
		password

Option 1 and Option 3 from the main menu are the only options that function at this time.
From the admin panel, the administrator has a few options to select from.
Currently only the logout option works.