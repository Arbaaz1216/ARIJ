#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <fstream>
#include <iostream>
#include <string>
#include <QFile>
#include <QTextStream>

QString userPt;

using namespace std;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_Admin_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(1);
}

void MainWindow::on_pushButton_Student_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(2);
}

void MainWindow::on_pushButton_Return_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_Return_2_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_AdminLogin_clicked()
{
    QString usernameAdmin = ui->lineEdit_AdminLogin->text();
    QString passwordAdmin = ui->lineEdit_AdminPass->text();

    string user = usernameAdmin.toStdString();
    string pass = passwordAdmin.toStdString();
    string un_ad,pw_ad;

ifstream read("data\\admin\\" + user + ".txt");
getline(read, un_ad);
getline(read, pw_ad);

if(un_ad == user && pass == pw_ad)
{
    QMessageBox::information(this, "Login File", "You have logged in as admin.");
    ui->stackedWidget_Main->setCurrentIndex(3);
}
else if (un_ad != user && pass != pw_ad) {
   QMessageBox::warning(this, "Login", "Incorrect username and password.");
}
    ui->lineEdit_AdminLogin->clear();
    ui->lineEdit_AdminPass->clear();
}

void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
}

void MainWindow::on_pushButton_StudLogin_clicked()
{
    QString usernameStud = ui->lineEdit_StudLogin->text();
    QString passwordStud = ui->lineEdit_StudPass->text();

    string userStud = usernameStud.toStdString();
    string passStud = passwordStud.toStdString();
    string un_st,pw_st;
    int id;

ifstream read("data\\students\\" + userStud + ".txt");
getline(read, un_st);
getline(read, pw_st);
read >> id;

if(un_st == userStud && passStud == pw_st)
{
    QMessageBox::information(this, "Login File", "You have logged in as a student.");
    ui->stackedWidget_Main->setCurrentIndex(4);
    QFile fileWelcome("data\\StudentWelcome.txt");
    if(!fileWelcome.open(QIODevice::ReadOnly))
        QMessageBox::information(0, "info", fileWelcome.errorString());

    QTextStream in(&fileWelcome);
   ui->textBrowser->setText(in.readAll());
   ui->label_13->setText(usernameStud);
   QString IDString = QString::number(id);
   ui->label_ID->setText(IDString);
}
else if (un_st != userStud && passStud != pw_st) {
   QMessageBox::warning(this, "Login", "Incorrect username and password.");
}
userPt = usernameStud;

ui->lineEdit_StudLogin->clear();
ui->lineEdit_StudPass->clear();
}

void MainWindow::on_pushButton_6_clicked()
{
        ui->stackedWidget_2->setCurrentIndex(1);
       QFile fileCourses("data\\students\\courses\\" + userPt + ".txt");
      if(!fileCourses.open(QIODevice::ReadOnly))
           QMessageBox::information(0, "info", fileCourses.errorString());

       QTextStream in(&fileCourses);
      ui->textBrowser_Courses->setText(in.readAll());

}

void MainWindow::on_pushButton_StudLogout_clicked()
{
    ui->stackedWidget_Main->setCurrentIndex(0);
        ClearAll();
}

void MainWindow::on_pushButton_8_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(0);
}

void MainWindow::on_pushButton_7_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(2);
   QFile fileGrades("data\\students\\grades\\" + userPt + ".txt");
   if(!fileGrades.open(QIODevice::ReadOnly))
       QMessageBox::information(0, "info", fileGrades.errorString());

   QTextStream in(&fileGrades);
  ui->textBrowser_Grades->setText(in.readAll());
}

void MainWindow::on_pushButton_GPA_clicked()
{
    double GPA = 0.0;
    QString GPAString = QString::number(GPA);
    ui->label_GPA->setText(GPAString);
}

void MainWindow::ClearAll()
{
    ui->label_GPA->clear();
}
